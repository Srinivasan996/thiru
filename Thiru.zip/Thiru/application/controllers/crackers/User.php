<?php
class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        //parent::__construct();
        $this->load->model('User_model');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library(array('form_validation', 'session'));
        $this->load->helper('form');
        $this->load->helper('html');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->library('upload');
        $this->load->database();
    }

    public function signup()
    {

        $this->load->view('signup_form');
    }

    public function submit()
    {

        $this->form_validation->set_rules('email', 'Email', 'required|is_unique[user.email]', array('is_unique' => 'Email already exists!'));
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('signup_form');
        } else {
            $data['name'] = $this->input->post('name');
            $data['email'] = $this->input->post('email');
            $data['password'] = $this->input->post('password');

            $response = $this->user_model->store($data);
            if ($response == true) {
                echo 'Succesfully registered';
            } else {
                echo 'Failed to register';
            }
        }

    }

    public function login()
    {

        if ($this->session->has_userdata('id')) {
            $this->load->view('crackers/SalesAdmin');
        }

        $this->load->view('crackers/login');
    }

    public function login_user()
    {

        // $this->form_validation->set_rules('email', 'Email', 'required');
        // $this->form_validation->set_rules('password', 'Password', 'required');

        /*  if ($this->form_validation->run() == false) {
        $this->load->view('crackers/login');
        } else { */
        $email = $this->input->post('username_login');
        $password = $this->input->post('password_login');
        $this->load->database();
        $this->load->model('user_model');

        $response = $this->user_model->SalesAdminLogin();
        $result = json_decode(json_encode($response), true);
        // $i = 0;
        foreach ($result as $qry) {
            $data['username'] = $qry['username'];
            $data['password'] = $qry['password'];
            $data['id'] = $qry['1'];

        }
        // $values = array('value' => isset($data) ? $data : null);
        //echo json_encode($values);

        if ($data['username'] == $email) {
            if ($data['password'] == $password) {
                $this->load->library('session');
                $this->session->set_userdata('id', $data['id']);
                //$this->load->view('crackers/SalesAdmin');
                // $myredirect_uri = base_url() . "crackers/user/home";
                // header("Location: " . $myredirect_uri);
                redirect('SalesAdmin');

            } else {
                echo "Login Error!";
            }
        } else {
            echo "No account exists with this email!";
        }
        // }

    }

    public function home()
    {

        $this->load->view('crackers/SalesAdmin');
    }

    public function logout()
    {

        $this->session->unset_userdata('id');
        redirect('user/login');
    }
}