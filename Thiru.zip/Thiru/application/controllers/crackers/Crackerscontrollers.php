<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Crackerscontrollers extends CI_Controller
{
    /**
     * Get All Data from this method.
     *
     * @return Response
     */
    public function __construct()
    {
        //load database in autoload libraries
        parent::__construct();
        $this->load->model('Crackersmodel');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library(array('form_validation', 'session'));
        $this->load->helper('form');
        $this->load->helper('html');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->library('upload');
        $this->load->database();
        //$base_url=base_url();

    }

    public function index()
    {
        $this->load->view('crackers/Home');
    }

    public function salesadmin()
    {
        $this->load->view('crackers/SalesAdmin');

    }
    public function order()
    {
        $this->load->view('crackers/order');

    }
    public function contactus()
    {
        $this->load->view('crackers/contactus');
    }
    public function payment()
    {
        $this->load->view('crackers/payment');
    }
    public function getproductlist()
    {
        $product_list = $this->Crackersmodel->getproductlist();
        $result = json_decode(json_encode($product_list), true);
        $i = 0;
        foreach ($result as $qry) {
            $data[$i]['product_id'] = $qry['product_id'];
            $data[$i]['product_name'] = $qry['product_name'];
            $data[$i]['content_item'] = $qry['content_item'];
            $data[$i]['actual_price'] = $qry['actual_price'];
            $data[$i]['discout_price'] = $qry['discout_price'];
            $data[$i]['final_price'] = $qry['final_price'];
            $data[$i]['stock_detail'] = $qry['stock_detail'];
            //$data[$i]['image_name'] = $qry['image_name'];
            $i++;
        }
        $values = array('value' => isset($data) ? $data : null);

        echo json_encode($values);
    }
    public function getOrderList()
    {
        $order_list = $this->Crackersmodel->getOrderList();
        $result = json_decode(json_encode($order_list), true);
        $i = 0;
        foreach ($result as $qry) {
            $data[$i]['orderid'] = $qry['orderid'];
            $data[$i]['phone'] = $qry['phone'];
            $data[$i]['customer'] = $qry['customer'];
            $data[$i]['email'] = $qry['email'];
            $data[$i]['address'] = $qry['address'];
            $data[$i]['Total_amount'] = $qry['Total_amount'];
            $i++;
        }
        $values = array('value' => isset($data) ? $data : null);

        echo json_encode($values);

    }
    public function getOrderListPaymentReceived()
    {
        $order_list = $this->Crackersmodel->getOrderListPaymentReceived();
        $result = json_decode(json_encode($order_list), true);
        $i = 0;
        foreach ($result as $qry) {
            $data[$i]['orderid'] = $qry['orderid'];
            $data[$i]['phone'] = $qry['phone'];
            $data[$i]['customer'] = $qry['customer'];
            $data[$i]['email'] = $qry['email'];
            $data[$i]['address'] = $qry['address'];
            $data[$i]['Total_amount'] = $qry['Total_amount'];
            $i++;
        }
        $values = array('value' => isset($data) ? $data : null);

        echo json_encode($values);

    }
    public function OrderItems()
    {
        $order_items = $this->input->post('order_items');
        $name = $this->input->post('name');
        $phone_number = $this->input->post('phone_number');
        $email = $this->input->post('email');
        $address = $this->input->post('address');
        $orderid = $this->input->post('orderid');
        $overall_total_amount = $this->input->post('overall_total_amount');
        //$r = $this->Crackersmodel->Orders($orderid,$name,$phone_number,$email,$address);
        $response = $this->Crackersmodel->OrderItems($order_items, $name, $phone_number, $email, $address, $orderid, $overall_total_amount);
        echo $response;
        // print_r($response);
        //print_r($order_items);
    }
    public function Orders()
    {
        $name = $this->input->post('name');
        $phone_number = $this->input->post('phone_number');
        $email = $this->input->post('email');
        $address = $this->input->post('address');
        $response = $this->Crackersmodel->Orders($name, $phone_number, $email, $address);
        //print_r($order_items);
        echo $response;
        print_r($response);

    }
    public function addNewProduct()
    {
        $product_code = $this->input->post('product_code');
        $product_name = $this->input->post('product_name');
        $content_item = $this->input->post('content_item');
        $actual_price = $this->input->post('actual_price');
        $discount_range = $this->input->post('discount_range');
        $final_price = $this->input->post('final_price');
        $stock = $this->input->post('stock');
        $response = $this->Crackersmodel->addNewProduc($product_code, $product_name, $content_item, $actual_price, $discount_range, $final_price, $stock);
        echo $response;
    }
    public function updateProduct()
    {
        $product_code = $this->input->post('product_code');
        $product_name = $this->input->post('product_name');
        $content_item = $this->input->post('content_item');
        $actual_price = $this->input->post('actual_price');
        $discount_range = $this->input->post('discount_range');
        $final_price = $this->input->post('final_price');
        $stock = $this->input->post('stock');
        $response = $this->Crackersmodel->updateProduct($product_code, $product_name, $content_item, $actual_price, $discount_range, $final_price, $stock);
        echo $response;

    }
    public function getProductDetails()
    {
        $getproduct_code = $this->input->post('getproduct_code');
        $response = $this->Crackersmodel->getProductDetails($getproduct_code);
        $result = json_decode(json_encode($response), true);
        foreach ($result as $qry) {
            $data['product_id'] = $qry['product_id'];
            $data['product_name'] = $qry['product_name'];
            $data['content_item'] = $qry['content_item'];
            $data['actual_price'] = $qry['actual_price'];
            $data['discout_price'] = $qry['discout_price'];
            $data['final_price'] = $qry['final_price'];
            $data['stock_detail'] = $qry['stock_detail'];
            //$data[$i]['image_name'] = $qry['image_name'];
        }
        $values = array('value' => isset($data) ? $data : null);

        echo json_encode($values);

    }
    public function updateDiscount()
    {
        $discount_price = $this->input->post('discount_price');
        $response = $this->Crackersmodel->updateDiscount($discount_price);
        echo $response;

    }
    public function deleteProduct()
    {
        $delete_product_code = $this->input->post('delete_product_code');
        $response = $this->Crackersmodel->deleteProduct($delete_product_code);
        echo $response;

    }
    public function UpdateOrderOpenClose()
    {
        $open_close = $this->input->post('open_close');
        $response = $this->Crackersmodel->UpdateOrderOpenClose($open_close);
        echo $response;

    }
    public function ViewOrderDetails()
    {
        $order_id = $_GET["order_id"];
        $data['order_id'] = $order_id;
        //$status = $_GET["status"];
        // $_SESSION['status'] = $status;
        $this->load->view('crackers/Vieworderdetails', $data);

    }
    public function getLatestRecord()
    {
        $response = $this->Crackersmodel->getLatestRecord();
        $result = json_decode(json_encode($response), true);
        foreach ($result as $qry) {
            $data['orderid'] = $qry['orderid'];
        }
        $orderid = $data['orderid'];
        // return $orderid;
        // print_r($data['orderid']);
        // exit;
        echo json_encode($orderid);

    }
    public function getOrderList_View()
    {
        $order_id_view = $this->input->post('order_id_view');
        $response = $this->Crackersmodel->getOrderList_View($order_id_view);
        $result = json_decode(json_encode($response), true);
        foreach ($result as $qry) {
            $data['orderid'] = $qry['orderid'];
            $data['Total_amount'] = $qry['Total_amount'];
            $data['phone'] = $qry['phone'];
            $data['status'] = $qry['status'];
            $data['customer'] = $qry['customer'];
            $data['email'] = $qry['email'];
            $data['address'] = $qry['address'];
            $data['Total_amount'] = $qry['Total_amount'];
            //$data[$i]['image_name'] = $qry['image_name'];
        }
        $values = array('value' => isset($data) ? $data : null);
        echo json_encode($values);

    }
    public function getOrderItemList_View()
    {
        $order_id_view = $this->input->post('order_id_view');
        $response = $this->Crackersmodel->getOrderItemList_View($order_id_view);
        $result = json_decode(json_encode($response), true);
        $i = 0;
        foreach ($result as $qry) {
            $data[$i]['orderid'] = $qry['orderid'];
            $data[$i]['product_name'] = $qry['product_name'];
            $data[$i]['content_item'] = $qry['content_item'];
            $data[$i]['actual_price'] = $qry['actual_price'];
            $data[$i]['discountminus_price'] = $qry['discountminus_price'];
            $data[$i]['final_price'] = $qry['final_price'];
            $data[$i]['quantity'] = $qry['quantity'];
            $data[$i]['item_total'] = $qry['item_total'];
            //$data[$i]['image_name'] = $qry['image_name'];
            $i++;
        }

        $values = array('value' => isset($data) ? $data : null);

        echo json_encode($values);

    }
    public function UpdateStatus()
    {
        $status = $this->input->post('status');
        $order_id = $this->input->post('orderid');
        $response = $this->Crackersmodel->UpdateStatus($order_id, $status);
        echo $response;

    }
    public function login()
    {

        if ($this->session->has_userdata('id')) {
            $this->load->view('crackers/SalesAdmin');
            // $this->salesadmin();

        }

        $this->load->view('crackers/login');
    }
    public function logout()
    {

        $this->session->unset_userdata('id');
        redirect('login');
    }
    public function SalesAdminLogin()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $response = $this->Crackersmodel->SalesAdminLogin();
        $result = json_decode(json_encode($response), true);
        $i = 0;
        foreach ($result as $qry) {
            $data['username'] = $qry['username'];
            $data['password'] = $qry['password'];
            $data['id'] = $qry['1'];
        }
        if ($data['username'] == $email) {
            if ($data['password'] == $password) {
                $this->load->helper('url');

                $this->load->library('session');
                $this->session->set_userdata('id', $data['id']);
                redirect('sales');
                $data['message'] = 'success';
            } else {
                $data['message'] = 'error';

            }
        } else {
            $data['message'] = "No_account";
        }
    }
    public function sales()
    {
        $this->load->view('crackers/SalesAdmin');

    }
    public function OrderOpenClosed()
    {
        $response = $this->Crackersmodel->OrderOpenClosed();
        $result = json_decode(json_encode($response), true);
        foreach ($result as $qry) {
            $data['id'] = $qry['id'];
            $data['orderopen_closed'] = $qry['orderopen_closed'];
            $_SESSION['orderopen_closed'] = $qry['orderopen_closed'];
        }
        $values = array('value' => isset($data) ? $data : null);
        echo json_encode($values);

    }
    public function CheckProduct()
    {
        $product_list = $this->Crackersmodel->getproductlist();
        $result = json_decode(json_encode($product_list), true);
        $i = 0;
        foreach ($result as $qry) {
            $data[$i]['product_id'] = $qry['product_id'];
            $data[$i]['product_name'] = $qry['product_name'];
            $data[$i]['content_item'] = $qry['content_item'];
            $data[$i]['actual_price'] = $qry['actual_price'];
            $data[$i]['discout_price'] = $qry['discout_price'];
            $data[$i]['final_price'] = $qry['final_price'];
            $data[$i]['stock_detail'] = $qry['stock_detail'];
            //$data[$i]['image_name'] = $qry['image_name'];
            $i++;
        }
        $values = array('value' => isset($data) ? $data : null);

        echo json_encode($values);

    }
}