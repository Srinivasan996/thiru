<?php
defined('BASEPATH') or exit('No direct script access allowed');
class PdfControllers extends CI_Controller
{
    /**
     * Get All Data from this method.
     *
     * @return Response
     */
    public function __construct()
    {
        //load database in autoload libraries
        parent::__construct();
        $this->load->model('Crackersmodel');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library(array('form_validation', 'session'));
        $this->load->helper('form');
        $this->load->helper('html');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->library('upload');
        $this->load->database();
        $this->load->library('pdf');

        //$base_url=base_url();

    }
    public function index() 
	{
       return view('Vieworderdetails');
      // $this->load->view('Pdfview');
    }    

    public function convertToPdf(){
        $html = $this->load->view('crackers/Vieworderdetails', true);  
        $id=1;
        $dompdf = new \Dompdf\Dompdf(); 
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();
       // $dompdf->stream();
      $dompdf->stream("".$id.".pdf", array("Attachment"=>0));
    } 
}