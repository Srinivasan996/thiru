<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dompdf_controller extends CI_Controller {
     public function __construct()
    {
        //load database in autoload libraries
        parent::__construct();
        $this->load->model('Crackersmodel');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library(array('form_validation', 'session'));
        $this->load->helper('form');
        $this->load->helper('html');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->library('upload');
        $this->load->database();
        $this->load->library('pdf');

        //$base_url=base_url();

    }
    
    public function index(){
        // echo "string";die();
       
    }
    public function convertToPdf(){
         $this->load->view('crackers/Pdfview.php');
        
        // Get output html
        $html = $this->output->get_output();
        
        // Load pdf library
        $this->load->library('pdf');
        
        // Load HTML content
        $this->dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation
        $this->dompdf->setPaper('A4', 'potrait');
        
        // Render the HTML as PDF
        $this->dompdf->render();
        
        // Output the generated PDF (1 = download and 0 = preview)
        $this->dompdf->stream("order.pdf", array("Attachment"=>0));

    }
    
}