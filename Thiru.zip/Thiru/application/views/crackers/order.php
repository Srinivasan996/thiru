<!DOCTYPE html>
<html lang="en">
<?php
include 'Header.php';
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="js/jquery.fireworks.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
    <script type="text/javascript">
    (function() {
        emailjs.init("user_LsELqCmbqfjgOBQvu71C1");
    })();
    </script>

</head>

<style>
@import url(https://fonts.googleapis.com/css?family=Montserrat:400,700);

#body {
    margin: 0px;
}


#form {
    max-width: 420px;
    margin: 50px auto;
}

.feedback-input {
    color: black;
    font-family: Helvetica, Arial, sans-serif;
    font-weight: 500;
    font-size: 18px;
    border-radius: 5px;
    line-height: 22px;
    // background-color: transparent;
    border: 2px solid #CC6666;
    transition: all 0.3s;
    padding: 13px;
    margin-bottom: 15px;
    width: 100%;
    box-sizing: border-box;
    outline: 0;
}

.feedback-input:focus {
    border: 2px solid #CC4949;
}

textarea {
    height: 150px;
    line-height: 150%;
    resize: vertical;
}

[type="submit"] {
    font-family: 'Montserrat', Arial, Helvetica, sans-serif;
    width: 100%;
    background: #CC4949;
    border-radius: 5px;
    border: 0;
    cursor: pointer;
    color: white;
    font-size: 24px;
    padding-top: 10px;
    padding-bottom: 10px;
    transition: all 0.3s;
    margin-top: -4px;
    font-weight: 700;
}

#order_submit_btn:disabled {
    background-color: red;
}

#order_submit_btn:enabled {
    background-color: green;
}

/*[type="submit"]:hover {
    background: #CC4949;
    //#CC4949;

}*/

#simple_table table,
td,
th,
tr {
    border: 1px solid black;

}

th {
    text-align: center;
}

th #simple_table {
    font-size: 18px !important;
    background-color: #FE2E64 !important;
    color: white !important;
}
</style>
<script type="text/javascript">
var table_row;
var rs = "Rs.";
$(document).ready(function() {
    <?php if ($_SESSION['orderopen_closed'] == 'closed'): ?>
    Swal.fire({
        icon: 'warning',
        title: 'Order Closed',
        text: 'Something went wrong!'
    })
    <?php endif;?>

    //fetch list
    var list = '';
    var cnava = '';
    var total_price = 0;
    var customer_email;
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/getproductlist",
        dataType: "json",
        async: false,
        beforeSend: function() {

        },
        success: function(response) {
            for (var i = 0; i < response['value'].length; i++) {
                table_row = response['value'].length;
                //alert(table_row);
                var item = response['value'][i];
                // alert(item.content_item);
                var actual_price = item.actual_price;
                var discount = item.discout_price;
                actual_price = Number(actual_price);
                actual_price = actual_price.toFixed(2);
                // alert("actual price----" + actual_price);
                var discount_value = Number(discount) / 100;
                var totalValue = actual_price - (actual_price * discount_value);
                final_price = totalValue.toFixed(2);
                var discount_price = actual_price - Number(final_price);
                discount_price = discount_price.toFixed(2);
                //console.log(item.stock_detail);
                list = list + '<tr id="row_' + i + '">';
                list = list +
                    '<td class="" style="text-align:left;color:white;"> <input type = "hidden" class="order-form" id = "productid_' +
                    i + '" name="productid_' + i + '" value = ' + item.product_id +
                    '>' + item
                    .product_id + '</td>';
                list = list +
                    '<td class="cart-product-name-info" style="word-wrap:break-word;"  id = "productName_td' +
                    i + '"> <input type = "hidden" class="order-form" name = "productName_' +
                    i + '"  id = "productName_' + i + '" value = "' + item.product_name +
                    '" style = "width:100px;"><h5 class = cart-product-description style="color:White;" >' +
                    item.product_name + '</h5><h5 <span id = "productName_stock' + i +
                    '"></span> </h5> </td >';
                list = list +
                    '<td class="cart-product-edit" style="color: yellow;font-weight: 800;">' +
                    item.content_item +
                    '<input type="hidden" class ="order-form" id="contentItem_' + i +
                    '" value="' + item.content_item + '"></td>';

                list = list +
                    '<td class="cart-product-sub-total"> <span class = "cart-sub-total-price" style="color: #fd07c8;font-weight: bold;font-size: 10px;"><span>' +
                    rs + '</span>' +
                    actual_price +
                    '</span><br><input type="hidden" class="order-form" id="actual_price' +
                    i +
                    '" value=' + actual_price +
                    ' style="width:100px;"> <input type="hidden" class="order-form" id="discount_range' +
                    i +
                    '" value=' + item.discout_price +
                    ' style="width:100px;"> </td>';

                list = list +
                    '<td class="cart-product-sub-total"><span class="cart-sub-total-price"><strike style="color: red;font-weight:bold;font-size: 10px;"> <span>' +
                    rs + '</span>' +
                    discount_price + '</strike></span><input type="hidden" id="offerPrice_' +
                    i +
                    '" name="offerPrice_' +
                    i +
                    '" class="order-form" value=' + discount_price +
                    ' ondrop="return false;" onpaste="return false;" /></td>';
                list = list +
                    ' <td class="cart-product-sub-total"><span class="cart-sub-total-price" style="color: #01fb01;font-weight: 800;font-size: 10px;"><span>' +
                    rs + '</span>' +
                    final_price + '</span>><input type="hidden" id="finalPrice_' + i +
                    '" name="finalPrice_' + i +
                    '" class="order-form" value=' + final_price +
                    ' ondrop="return false;" onpaste="return false;" /></td>';

                list = list +
                    '<td class="cart-product-quantity"> <input type = "text" size="4" style = "padding:4px;" name = "quantity' +
                    i +
                    '" id = "quantity' +
                    i +
                    '" class = "order-form" onkeyup ="itemquantitytotal(' + i +
                    ')"><input type = "text" name = "stock' +
                    i +
                    '" id = "stock' +
                    i +
                    '" value="' + item.stock_detail +
                    '" hidden  /> <input type="image" name = "image_hide' + i +
                    '" id = "image_hide' + i + '"  onload="MakeStockDisabled(' + i +
                    ')""  src="images/logo.jpg" alt="Submit" width="48" height="48" ><span id="order_closed_span' +
                    i + '"  hidden style="color:red;font-weight:bold;">Booking Closed</span></td>';

                list = list +
                    '<td class="" style="text-align:left;"><input type="number" readonly id="total_' +
                    i +
                    '" class="total" style="color:white;background:black; border:none;font-size: 10px;"value=' +
                    total_price + ' ></td>';
                list = list + '</tr>';
                //var total = $("#totalHide_'+i+' ").val();
                //console.log(total);


            }
            document.getElementById('list').innerHTML = list;

        },


    });


    // Function code here.
    $('.fireworks').fireworks({
        sound: false, // sound effect
        opacity: 0.4,
        width: '100%',
        height: '100%'
    });
    $('.fireworks2').fireworks({
        sound: false, // sound effect
        opacity: 0.4,
        width: '100%',
        height: '100%'
    });
    $('.section').fireworks({
        sound: false, // sound effect
        opacity: 0.4,
        width: '100%',
        height: '100%'
    });

});
$(document).ready(function() {
    $('input').attr('autocomplete', 'off');
    var fixmeTop = $('.fixme').offset().top;
    $(window).scroll(function() {
        var currentScroll = $(window).scrollTop();
        if (currentScroll >= fixmeTop) {
            $('.fixme').css({
                position: 'fixed',
                top: '0',
                left: '0'
            });
        } else {
            $('.fixme').css({
                position: 'static'
            });
        }
    });
});


function MakeStockDisabled(i) {
    var stock = $('#stock' + i + '').val();
    //console.log("disabledfunctioncall");
    var discount_range = $('#discount_range' + i + '').val();
    // alert(discount_range);
    $('#discount_price_th').text(discount_range).css("font-weight", "bold");
    if (stock == 'out') {
        $('#quantity' + i + '').attr('disabled', 'disabled');
        var productName_td = $('#productName_td' + i + '').text();
        //alert(productName_td);
        $('#productName_stock' + i + '').text("Out Of Stock").css("color", "red");
    }
    $('#image_hide' + i + '').attr('hidden', 'true');

    <?php if ($_SESSION['orderopen_closed'] == 'closed'): ?>
    $('#quantity' + i + '').attr('hidden', 'true');
    $('#order_closed_span' + i + '').removeAttr('hidden');
    $('#form_name').attr('disabled', 'true');
    $('#form_email').attr('disabled', 'true');
    $('#form_phone').attr('disabled', 'true');
    $('#form_address').attr('disabled', 'true');

    <?php endif;?>

}



function itemquantitytotal(i) {
    var item_price = $('#finalPrice_' + i + '').val();
    var qty = $('#quantity' + i + '').val();
    var total = item_price * qty;
    total = Number(total);
    total = total.toFixed(2);
    $('#total_' + i + '').val(total);
    $('#totalHide_' + i + '').val(total);
    overalltotal();
}

function overalltotal() {
    $(document).ready(function() {
        var sum = 0;
        $(".total").each(function() {
            sum = sum + Number($(this).val());
            // sum = Number(sum);
            // sum = sum.toFixed(2);
        });
        $('#results_bottom').text(sum);
        // alert(sum);
    });

}

function SubmitOrder() {
    //e.preventDefault();
    if ($('#form_name').val().length > 0 &&
        $('#form_phone').val().length > 0 &&
        $('#form_email').val().length > 0 &&
        $('#form_address').val().length > 0) {
        var arrData = [];
        var name = $('#form_name').val();
        var phone_number = $('#form_phone').val();
        var email = $('#form_email').val();
        var address = $('#form_address').val();
        var order = 'TAC';
        var digits = '0123456789';
        var overall_total_amount = $('#results_bottom').text();
        for (let i = 0; i < 4; i++) {
            order += digits[Math.floor(Math.random() * 10)];
        }
        // loop over each table row (tr)
        $("#list_table tr").each(function() {
            var currentRow = $(this);
            var product_id = currentRow.find("td:eq(0) input[type='hidden']").val();
            var product_name = currentRow.find("td:eq(1) input[type='hidden']").val();
            var content_item = currentRow.find("td:eq(2) input[type='hidden']").val();
            var actual_price = currentRow.find("td:eq(3) input[type='hidden']").val();
            // var content_item = currentRow.find("td:eq(3) input[type='hidden']").val();
            var discount_price = currentRow.find("td:eq(4) input[type='hidden']").val();
            var final_price = currentRow.find("td:eq(5) input[type='hidden']").val();
            var quantity = currentRow.find("td:eq(6) input[type='text']").val();
            var item_total = currentRow.find("td:eq(7)  input[type='number']").val();
            var obj = {};
            obj.product_id = product_id;
            obj.product_name = product_name;
            obj.content_item = content_item;
            obj.actual_price = actual_price;
            obj.discount_price = discount_price;
            obj.final_price = final_price;
            obj.quantity = quantity;
            obj.item_total = item_total;
            arrData.push(obj);
        });
        //----------------------------------------
        Swal.fire({
            icon: 'question',
            title: 'Are you sure submit the order?',
            showDenyButton: true,
            showCancelButton: true,
            confirmButtonText: 'Yes Order it',
            denyButtonText: `NO Order it`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: "crackers/Crackerscontrollers/OrderItems",
                    dataType: "json",
                    data: {
                        order_items: arrData,
                        name: name,
                        phone_number: phone_number,
                        email: email,
                        address: address,
                        orderid: order,
                        overall_total_amount: overall_total_amount
                    },
                    async: false,
                    beforeSend: function() {},
                    success: function(response) {
                        if (response) {
                            // Swal.fire('Ordered!', '', 'success')
                            $.ajax({
                                type: "POST",
                                url: "crackers/Crackerscontrollers/getLatestRecord",
                                dataType: "json",
                                data: {

                                },
                                async: false,
                                beforeSend: function() {},
                                success: function(response) {
                                    if (response) {
                                        // Swal.fire('Ordered!', '', 'success')
                                        //alert(response);

                                        var orderid_from_order = response;
                                        var OrderItemlist_pdf = '';
                                        var overall_total_amount;

                                        $.ajax({
                                            type: "POST",
                                            url: "crackers/Crackerscontrollers/getOrderList_View",
                                            data: {
                                                "order_id_view": orderid_from_order
                                            },
                                            dataType: "json",
                                            async: false,
                                            beforeSend: function() {

                                            },
                                            success: function(response) {
                                                //alert(response);
                                                var item = response[
                                                    'value'];
                                                $('#orderid').text(item
                                                    .orderid);
                                                $('#customer_phone').text(
                                                    item
                                                    .phone);
                                                $('#customer_name').text(
                                                    item
                                                    .customer);
                                                $('#customer_email').text(
                                                    item
                                                    .email);
                                                $('#customer_address').text(
                                                    item
                                                    .address);
                                                $('#status').val(item
                                                    .status);
                                                // alert(item.Total_amount);
                                                $('#overall_total_amount')
                                                    .text(
                                                        item.Total_amount);
                                                overall_total_amount =
                                                    Number(
                                                        item
                                                        .Total_amount);
                                                overall_total_amount =
                                                    overall_total_amount
                                                    .toFixed(2);

                                                //----------------PDF view---------------
                                                $('#orderid_pdf').text(item
                                                    .orderid);
                                                $('#customer_phone_pdf')
                                                    .text(
                                                        item.phone);
                                                $('#customer_name_pdf')
                                                    .text(
                                                        item.customer);
                                                $('#customer_email_pdf')
                                                    .text(
                                                        item.email);
                                                //var address_pdf = $('#customer_address') .text();
                                                $('#customer_address_pdf')
                                                    .text(
                                                        item.address);
                                                customer_email = item.email;
                                                //document.getElementById('order_list_table_body_customer_details').innerHTML = list;
                                            },


                                        });


                                        // var overall_total_amount = $('#overall_total_amount').text();
                                        $.ajax({
                                            type: "POST",
                                            url: "crackers/Crackerscontrollers/getOrderItemList_View",
                                            data: {
                                                "order_id_view": orderid_from_order
                                            },
                                            dataType: "json",
                                            async: false,
                                            beforeSend: function() {

                                            },
                                            success: function(response) {
                                                //alert(response);
                                                for (var i = 0; i <
                                                    response[
                                                        'value'].length; i++
                                                ) {
                                                    var s_no = i + 1;
                                                    var item = response[
                                                            'value']
                                                        [i];
                                                    var actual_price_pdf =
                                                        Number(item
                                                            .actual_price);
                                                    actual_price_pdf =
                                                        actual_price_pdf
                                                        .toFixed(2);


                                                    var discountminus_price_pdf =
                                                        Number(item
                                                            .discountminus_price
                                                        );
                                                    discountminus_price_pdf
                                                        =
                                                        discountminus_price_pdf
                                                        .toFixed(2);
                                                    var final_price_pdf =
                                                        Number(item
                                                            .final_price);
                                                    final_price_pdf =
                                                        final_price_pdf
                                                        .toFixed(2);
                                                    var item_total_pdf =
                                                        Number(
                                                            item
                                                            .item_total);
                                                    item_total_pdf =
                                                        item_total_pdf
                                                        .toFixed(2);
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<tr>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<td style="text-align: center;">' +
                                                        s_no + '</td>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<td style="text-align: center;">' +
                                                        item.product_name +
                                                        '</td>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<td style="text-align: center;">' +
                                                        item.content_item +
                                                        '</td>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<td style="text-align: center;"> <span>' +
                                                        rs + '</span>' +
                                                        actual_price_pdf +
                                                        '</td>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<td style="text-align: center;"> <span>' +
                                                        rs + '</span>' +
                                                        discountminus_price_pdf +
                                                        '</td>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<td style="text-align: center;"><span>' +
                                                        rs + '</span>' +
                                                        final_price_pdf +
                                                        '</td>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<td style="text-align: center;">' +
                                                        item.quantity +
                                                        '</td>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '<td style="text-align: center;"><span>' +
                                                        rs + '</span>' +
                                                        item_total_pdf +
                                                        '</td>';
                                                    OrderItemlist_pdf =
                                                        OrderItemlist_pdf +
                                                        '</tr>';
                                                }
                                                OrderItemlist_pdf =
                                                    OrderItemlist_pdf +
                                                    '<tr>';
                                                OrderItemlist_pdf =
                                                    OrderItemlist_pdf +
                                                    '<td colspan=7 style="text-align:right;"> Total Amount </td>';
                                                OrderItemlist_pdf =
                                                    OrderItemlist_pdf +
                                                    '<td style="text-align: center;"><span>' +
                                                    rs + '</span>' +
                                                    overall_total_amount +
                                                    '</td>';
                                                OrderItemlist_pdf =
                                                    OrderItemlist_pdf +
                                                    '</tr>';

                                                document.getElementById(
                                                        'order_list_table_body_item_details_pdf'
                                                    ).innerHTML =
                                                    OrderItemlist_pdf;
                                                $("#simple_table tr:even")
                                                    .css({
                                                        "background-color": "#FADBD8",
                                                        "font-size": "12px",
                                                        "font-weight": "bold"
                                                    });
                                                $("#simple_table tr:odd")
                                                    .css({
                                                        "background-color": "#A9F5F2",
                                                        "font-size": "12px",
                                                        "font-weight": "bold"
                                                    });
                                                //*************** Reset ********************* */
                                                var total_price = 0;
                                                /*   $('#orderreset').find(
                                                      'input:text').val('');
                                                  $('#orderreset').find(
                                                      'input:email').val('');
                                                  $('#orderreset').find(
                                                      'input:phone').val(
                                                      '');
                                                  $('#orderreset').find(
                                                      'textarea').val(
                                                      '');
                                                  $('#orderreset').find(
                                                      'input:hidden').val(
                                                      '');
                                                  $('#orderreset').find(
                                                      'input:submit').val(
                                                      ''); */
                                                // total_price = 0;
                                                $('#orderreset input[type="text"]')
                                                    .val('');
                                                $('#orderreset input[type="number"]')
                                                    .val('');
                                                $('#orderreset input[type="email"]')
                                                    .val('');
                                                $('#orderreset input[type="text"]')
                                                    .val('');
                                                $('#orderreset input[type="phone"]')
                                                    .val('');
                                                $('#orderreset textarea')
                                                    .val('');
                                                var sum = 0;
                                                $('#results_bottom').text(
                                                    sum);
                                                sendEmail();

                                            },
                                            //sendEmail()

                                        });


                                    }
                                }
                            });
                        }
                    }
                });
            } else if (result.isDenied) {
                Swal.fire('Order cancell', '', 'info')
            }
        });
        //---------------------------------
    } else {
        Swal.fire({
            //position: 'top-end',
            icon: 'error',
            title: 'Please Fill all required Field',
            showConfirmButton: false,
            timer: 1500
        })

    }
}

function sendEmail() {
    var table_items = document.getElementById("email").innerHTML;
    // var table_items_product = document.getElementById("product_list").innerHTML;
    var emailbody = '<html>';
    emailbody = emailbody +
        '<body><h3 style="background-color:Green; color:white; text-align:center;">Thiru Adhiyavan Crackers - Online Booking Details </h3><h3 style="background-color:red; color:white; text-align:center;">Summary Of Your Order Details</h3><br>';
    emailbody = emailbody + table_items;
    // emailbody = emailbody + table_items_product;
    emailbody = emailbody + '</body>';
    emailbody = emailbody + '</html>';
    // alert(emailbody);
    //console.log(emailbody);

    Email.send({
        Host: "smtp.gmail.com",
        Username: "thiruadhiyavancrackers2022@gmail.com",
        Password: "xiusrqqacujaeswc",
        To: customer_email,
        From: "thiruadhiyavancrackers2022@gmail.com",
        Subject: "Crackers Booking Details - Thiru Adhiyavan Crackers",
        Body: emailbody
    }).then(
        message => Swal.fire({
            title: 'Your order information will be sent to you through email.',
            showDenyButton: false,
            showCancelButton: false,
            confirmButtonText: 'Ok',
            //denyButtonText: `Don't save`,
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                // Swal.fire('Order Submitted', '', 'success')
                Swal.fire(' Your Order Submitted and Email Sent!', '', 'success')
            }
        })
    );
    /*   Email.send({
         // SecureToken: "dd8fbfd9-ab8a-4276-9df4-fe4c98377019",

          To: 'srinivasanmaha959@gmail.com',
          From: "sriniblog1@gmail.com",
          Subject: "Thiru Crackers",
          Body: "And this is the body"
      }).then(
          message => alert("mail sent successfully smtpjs")
      ); */
}
/* $(document).ready(function() {
    // On change in any of the fields with the class vcheck we run this function
    //  $('.feedback-input vcheck').change(function() {
    // We store the values of each input field in a variable
    $('.feedback-input vcheck').on('input change', function() {
        alert("call");
        var name = $('#form_name').val();
        var phone = $('#form_phone').val();
        var email = $('#form_email').val();
        var address = $('#form_address').val();
        // We check for null (empty) values
        if (name == '' || address == '' || email == '' || phone == '') {
            // When we find something blank set or keep the button to disabled
            $('#order_submit_btn').attr('disabled', 'disabled');
        } else {
            // When all conditions are met and values are good we enable the button
            $('#order_submit_btn').removeAttr('disabled');
        }
    });
}); */

$(document).ready(function() {
    validate();
    $('#form_name, #form_phone, #form_email,#form_address').change(validate);

});

function validate() {
    //console.log(" Name" + $('#form_name').val().length);
    //console.log(" phone" + $('#form_phone').val().length);
    //console.log(" email" + $('#form_email').val().length);
    //console.log(" address" + $('#form_address').val().length);
    if ($('#form_name').val().length > 0 &&
        $('#form_phone').val().length > 0 &&
        $('#form_email').val().length > 0 &&
        $('#form_address').val().length > 0) {
        $('#order_submit_btn').removeAttr('disabled');
        //alert("call");
    } else {
        $('#order_submit_btn').attr('disabled', 'true');
    }
}

function controle(mail) {
    Swal.fire({
        title: 'Are you sure your email address is correct?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Yes',
        denyButtonText: `NO`,
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            // Swal.fire('Saved!', '', 'success')
            if (IsEmail(mail) == true) {
                Swal.fire({
                    //position: 'top-end',
                    icon: 'success',
                    title: 'Valid Email Address',
                    showConfirmButton: false,
                    timer: 1500
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid Email address...',
                    text: 'Please Enter Valid Email address'
                })
                $('#form_email').val('');
            }
        } else if (result.isDenied) {
            Swal.fire('Changes are not saved', '', 'info')
            $('#form_email').val('');
        }
    })
}

function IsEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!regex.test(email)) {
        return false;
    } else {
        return true;
    }
}

function ValidateNo() {
    var phoneNo = document.getElementById('form_phone');
    if (phoneNo.value.length < 10 || phoneNo.value.length > 10) {
        Swal.fire({
            icon: 'error',
            title: 'Mobile No. is not valid',
            text: 'Please Enter 10 Digit Mobile No'
        })
        $('#form_phone').val('');
        return false;
    }

    //alert("Success ");
    // return true;
}
</script>
<script>
// style="background-color: rgba(184, 40, 8, 0.968);"
/* $(document).ready(function() {
    let canvas = document.getElementsByClassName('canvasall');
    for (var i = 1; i <= 28; i++) {
        let ctx = canvas[i].getContext('2d')
        const PI2 = Math.PI * 2
        const random = (min, max) => Math.random() * (max - min + 1) + min | 0
        const timestamp = _ => new Date().getTime()

        // container
        class Birthday {
            constructor() {
                this.resize()

                // create a lovely place to store the firework
                this.fireworks = []
                this.counter = 0

            }

            resize() {
                this.width = canvas.width = window.innerWidth
                let center = this.width / 2 | 0
                this.spawnA = center - center / 4 | 0
                this.spawnB = center + center / 4 | 0

                this.height = canvas.height = window.innerHeight
                this.spawnC = this.height * .1
                this.spawnD = this.height * .5

            }

            onClick(evt) {
                let x = evt.clientX || evt.touches && evt.touches[0].pageX
                let y = evt.clientY || evt.touches && evt.touches[0].pageY

                let count = random(3, 5)
                for (let i = 0; i < count; i++) this.fireworks.push(new Firework(
                    random(this.spawnA, this.spawnB),
                    this.height,
                    x,
                    y,
                    random(0, 260),
                    random(30, 110)))

                this.counter = -1

            }

            update(delta) {
                ctx.globalCompositeOperation = 'hard-light'
                ctx.fillStyle = `rgba(20,20,20,${ 7 * delta })`
                ctx.fillRect(0, 0, this.width, this.height)

                ctx.globalCompositeOperation = 'lighter'
                for (let firework of this.fireworks) firework.update(delta)

                // if enough time passed... create new new firework
                this.counter += delta * 3 // each second
                if (this.counter >= 1) {
                    this.fireworks.push(new Firework(
                        random(this.spawnA, this.spawnB),
                        this.height,
                        random(0, this.width),
                        random(this.spawnC, this.spawnD),
                        random(0, 360),
                        random(30, 110)))
                    this.counter = 0
                }

                // remove the dead fireworks
                if (this.fireworks.length > 1000) this.fireworks = this.fireworks.filter(firework => !
                    firework
                    .dead)

            }
        }

        class Firework {
            constructor(x, y, targetX, targetY, shade, offsprings) {
                this.dead = false
                this.offsprings = offsprings

                this.x = x
                this.y = y
                this.targetX = targetX
                this.targetY = targetY

                this.shade = shade
                this.history = []
            }
            update(delta) {
                if (this.dead) return

                let xDiff = this.targetX - this.x
                let yDiff = this.targetY - this.y
                if (Math.abs(xDiff) > 3 || Math.abs(yDiff) > 3) { // is still moving
                    this.x += xDiff * 2 * delta
                    this.y += yDiff * 2 * delta

                    this.history.push({
                        x: this.x,
                        y: this.y
                    })

                    if (this.history.length > 20) this.history.shift()

                } else {
                    if (this.offsprings && !this.madeChilds) {

                        let babies = this.offsprings / 2
                        for (let i = 0; i < babies; i++) {
                            let targetX = this.x + this.offsprings * Math.cos(PI2 * i / babies) | 0
                            let targetY = this.y + this.offsprings * Math.sin(PI2 * i / babies) | 0

                            birthday.fireworks.push(new Firework(this.x, this.y, targetX, targetY, this
                                .shade,
                                0))

                        }

                    }
                    this.madeChilds = true
                    this.history.shift()
                }

                if (this.history.length === 0) this.dead = true
                else if (this.offsprings) {
                    for (let i = 0; this.history.length > i; i++) {
                        let point = this.history[i]
                        ctx.beginPath()
                        ctx.fillStyle = 'hsl(' + this.shade + ',100%,' + i + '%)'
                        ctx.arc(point.x, point.y, 1, 0, PI2, false)
                        ctx.fill()
                    }
                } else {
                    ctx.beginPath()
                    ctx.fillStyle = 'hsl(' + this.shade + ',100%,50%)'
                    ctx.arc(this.x, this.y, 1, 0, PI2, false)
                    ctx.fill()
                }

            }
        }
        let then = timestamp()

        let birthday = new Birthday
        window.onresize = () => birthday.resize()
        document.onclick = evt => birthday.onClick(evt)
        document.ontouchstart = evt => birthday.onClick(evt)

        ;
        (function loop() {
            requestAnimationFrame(loop)

            let now = timestamp()
            let delta = now - then
            then = now
            birthday.update(delta / 1000)

        })()
    }
}); */
</script>

<body id="body" style="background-color:#FFFFC2;">
    <!-- <div class="fireworks">
    </div> -->
    <!-- style="vertical-align:middle; position:fixed; bottom:0; left:0; background:green; width:100%; font-size:1.5em;
        height:45px; padding:5px; color:white; z-index:2000; text-align:center"-->
    <div class="container-fluid p-0">
        <!--Carousel-->
        <div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="images/banner4.jpg" class="img-fluid w-100 d-block" alt="THiru Adhiyavan Crackers"
                        title="THiru Adhiyavan Crackers">
                </div>
                <div class="carousel-item">
                    <img src="images/banner2.png" class="img-fluid w-100 d-block" alt="THiru Adhiyavan Crackers"
                        title="THiru Adhiyavan Crackers">
                </div>
                <div class="carousel-item">
                    <img src="images/banner3.jpg" class="img-fluid w-100 d-block" alt="THiru Adhiyavan Crackers"
                        title="THiru Adhiyavan Crackers">
                </div>

            </div>
            <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <!--Carousel End-->
    </div>
    <div id="orderreset">
        <div class="container-fluid">
            <div class="row">
                <div class="fixme" style="vertical-align:middle;background:green; width:100%; font-size:2.5em;
        height:45px; padding:5px; color:white; z-index:100; text-align:center;">
                    Net Total : <span class="totals" id="results_bottom">0</span>
                </div>
            </div>
        </div>

        <div class="container-fluid" id="product_list">
            <div class="row">
                <div class="table">
                    <table class="table table-responsive table-borderless" id="list_table"
                        style="background-color: black;" disabled>
                        <thead style="background-color:#800000; color:white">
                            <tr>
                                <th class="text" style="text-align: left;width:5%;word-wrap:break-word;">P.Code</th>
                                <th class="text" style="text-align: left;width:10%;word-wrap:break-word;">Product Name
                                </th>
                                <th class="text" style="text-align: left;width:15%;word-wrap:break-word;">Content Item
                                </th>
                                <th class="text" style="text-align: left;width:10%;word-wrap:break-word;">Actual Rate
                                </th>
                                <th class="text" style="text-align: left;width:10%;word-wrap:break-word;"><span
                                        id="discount_price_th"></span>%OFF</th>
                                <th class="text" style="text-align: left;width:10%;word-wrap:break-word;">Price</th>
                                <th class="text" style="text-align: left;width:10%;word-wrap:break-word;">Qty</th>
                                <th class="text" style="text-align: left;width:10%;word-wrap:break-word;">Total</th>

                        <tbody id="list">
                        </tbody>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div id="form">
                        <input name="name" type="text" class="feedback-input vcheck" id="form_name" placeholder="Name"
                            required />
                        <input name="phone" type="phone" class="feedback-input vcheck" id="form_phone"
                            placeholder="Phone Number" required maxlength="10" pattern="\d{10}"
                            title="Please enter exactly 10 digits" onchange="ValidateNo();" />
                        <input name="email" type="email" class="feedback-input vcheck" id="form_email"
                            placeholder="Email" onchange="controle(this.value);" required />
                        <span id="error_email"></span>
                        <textarea name="text" class="feedback-input vcheck" id="form_address" placeholder="Address"
                            style="word-wrap:break-word;" required></textarea>
                        <input type="submit" id="order_submit_btn" value="Submit Order" onclick="SubmitOrder()" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="email" hidden>
        <div id="customer_details">
            <div class="row">
                <div class="col-6">
                    <label class="label_details">OrderID : </label><span id="orderid_pdf"> </span><br>
                    <label class="label_details">Mobile Number : </label><span id="customer_phone_pdf"></span><br>
                    <label class="label_details">Customer Name : </label><span id="customer_name_pdf"></span><br>
                    <label class="label_details">Email : </label> <span id="customer_email_pdf"></span><br>
                    <label class="label_details">Address : </label>
                    <span id="customer_address_pdf" style="word-break: break-all;"></span>

                </div>
            </div>
        </div>
        <br>
        <br>
        <div id="styledTable">
            <table class="table table-striped" id="simple_table">
                <thead>
                    <tr style="background-color:#FE2E64; color:red;">
                        <th>S No</th>
                        <th>Product Name</th>
                        <th>Content Items</th>
                        <th>Actual Price</th>
                        <th>Discount Price</th>
                        <th>Final Price</th>
                        <th>Qty</th>
                        <th>TotalPrice</th>
                    </tr>
                </thead>
                <tbody id="order_list_table_body_item_details_pdf">
                    <!--style="background-color:#BEF781;"-->
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>