<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <title>Thiru Adhiyavan Crackers</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="js/jquery.fireworks.js"></script>

    <meta name="description"
        content="Thiruadhiyavan Crackers is the best online crackers shop in Palacode Dharmapuri. Buy Diwali Crackers Gift Box Online from Thiruadhiyavan Crackers Palacode Dharmapuri." />
    <meta name="keywords"
        content="Pattasu Kadai in Palacode Dharmapuri, Online Pattasu Kadai, Online Crackers in Palacode Dharmapuri, Pattasukadia Dealers in Palacode Dharmapuri, Thiruadhiyavan Crackers is the best online crackers shop in Palacode Dharmapuri. Buy Diwali Crackers Gift Box Online from Thiruadhiyavan Crackers Palacode Dharmapuri, Tamilnadu, South india, Nort india, India" />
    <meta name="abstract"
        content="Thiruadhiyavan Crackers is the best online crackers shop in Palacode Dharmapuri. Buy Diwali Crackers Gift Box Online from Thiruadhiyavan Crackers Palacode Dharmapuri, Tamilnadu, South india, Nort india, India" />
    <meta name="page-topic"
        content="Thiruadhiyavan Crackers is the best online crackers shop in Palacode Dharmapuri. Buy Diwali Crackers Gift Box Online from Thiruadhiyavan Crackers Palacode Dharmapuri, Tamilnadu, South india, Nort india, India" />
    <meta name="page-type"
        content="Thiruadhiyavan Crackers is the best online crackers shop in Palacode Dharmapuri. Buy Diwali Crackers Gift Box Online from Thiruadhiyavan Crackers Palacode Dharmapuri, Tamilnadu, South india, Nort india, India" />
    <meta name="language" content="en" />
    <meta name="editors-url" content="index.html" />
    <meta name="coverage" content="worldwide" />
    <meta name="country" content="India" />
    <meta name="State" content="Tamil Nadu" />
    <meta name="city" content="Dharmapuri" />
    <meta name="author"
        content=" Thiruadhiyavan Crackers in Palacode Dharmapuri - www.thiruadhiyavancrackers.infinityfreeapp.com/" />
    <meta name="site" content="Thiruadhiyavan Crackers in Palacode Dharmapuri" />
    <meta name="distribution" content="global" />
    <meta name="Robots" content="INDEX,ALL" />
    <meta name="YahooSeeker" content="INDEX, FOLLOW" />
    <meta name="msnbot" content="INDEX, FOLLOW" />
    <meta name="googlebot" content="INDEX, FOLLOW" />
    <meta name="language" content="english" />
    <meta name="Expires" content="never" />
    <meta name="revisit-after" content="Daily" />
    <meta name="Author" content="Thiruadhiyavan Crackers in Palacode Dharmapuri" />
    <meta name="Distribution" content="Global" />
    <meta name="Rating" content="general" />
    <meta name="region" content="India" />
    <meta name="geo.region" content="Tamilnadu" />
    <meta name="search engines" content="ALL" />
    <meta name="robots" content="all,follow" />
    <meta name="robots" content="index, follow" />
    <meta name="publisher"
        content="Online Crackers Palacode Dharmapuri, Best Crackers Palacode Dharmapuri, Buy Online Crackers Gift Box Palacode Dharmapuri, 60 % Offers" />
    <meta name="copyright" content="index.html" />
    <meta name="owner"
        content="Online Crackers Palacode Dharmapuri, Best Crackers Palacode Dharmapuri, Buy Online Crackers Gift Box Palacode Dharmapuri, 60 % Offers" />

</head>


<style>
.button-76 {
    background-color: #cf245f;
    background-image: linear-gradient(to bottom right, #fcd34d, #ef4444, #ec4899);
    border: 0;
    border-radius: .25rem;
    box-sizing: border-box;
    color: #fff;
    cursor: pointer;
    font-family: ui-sans-serif, system-ui, -apple-system, system-ui, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto
Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
font-size: 1.125rem;
    /* 18px */
    font-weight: 600;
    line-height: 1.75rem;
    /* 28px */
    padding: 1rem 1.25rem;
    text-align: center;
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
}

.button-76:hover {
    box-shadow: none;
}

@media (min-width: 1024px) {
    .button-76 {
        font-size: 1.5rem;
        /* 24px */
        padding: 1rem 1.5rem;
        line-height: 2rem;
        /* 32px */
    }
}

/* navbar */
.navbar-toggler {
    position: relative;
    margin-top: 8px;
    margin-bottom: 8px;
    padding: 9px 13px !important;
    margin-left: 43%;
    color: #f20505 !important;
    border: 2px solid #3700b0 !important;
}

.navbar-toggle .icon-bar {
    background-color: #fff !important;
}

.navbar-light .navbar-nav .nav-link {
    color: #45007b !important;
    font-weight: 600;
    padding: 0px 25px !important;
    font-size: 16px;
}

.side>ul>li {
    display: block;
    padding: 10px 0px;
}

.navbar-light .navbar-nav .active>.nav-link {
    color: #f00505 !important;
    font-size: 16px;
}

.navbar-light .navbar-nav .nav-link:focus,
.navbar-light .navbar-nav .nav-link:hover {
    color: #f10505 !important;
}

@media(min-width:290px) and (max-width:767px) {
    .navbar {
        display: block;
    }

    .navbar-nav li a {
        text-align: center;
    }

    .mt-4 {
        margin-top: 25px !important;
    }

    .p-5 {
        padding: 15px !important;
    }

    .mt-5 {
        margin-top: 15px !important;
    }

    .p-4 {
        padding: 15px !important;
    }

    .pt-5 {
        padding-top: 40px !important;
    }

    .px-5 {
        padding-right: 15px !important;
        padding-left: 15px !important;
    }

    .px-4 {
        padding-right: 15px !important;
        padding-left: 15px !important;
    }

    .mt-3 {
        margin-top: 10px !important;
    }

    .t1 {
        text-align: center !important;
    }

    .pb-5 {
        padding-bottom: 10px !important;
    }

    a {
        font-size: 14px;
    }

    h1 {
        font-size: 25px;
    }

    .head h1 {
        font-size: 18px;
    }

    .head a {
        font-size: 11px;
    }

    .pb-3 {
        padding-bottom: 0px !important;
    }

    .navbar-nav li {
        line-height: 45px;
    }

    .parallax {
        height: 0;
    }

    h2 {
        font-size: 27px;
    }

    h3 {
        font-size: 25px;
    }

    .iconsize {
        width: 90px;
        height: 58px;
    }

    .w1 {
        width: 100%;
    }

    .w2 {
        width: 100%;
    }

    .bckimg {
        height: auto;
    }
}

@media(min-width:290px) and (max-width:320px) {
    .smallborder1 {
        margin-left: calc(38% - 0px);
    }
}

@media(min-width:320px) and (max-width:370px) {
    .parallax {
        height: 0;
    }

    h2 {
        font-size: 27px;
    }

    .pt-5 {
        padding-top: 40px !important;
    }

    .head a {
        font-size: 12px !important;
    }

    .head h1 {
        font-size: 21px;
    }

    .bckimg {
        height: auto;
    }

    .smallborder1 {
        margin-left: calc(42% - 0px);
    }
}

@media(min-width:371px) and (max-width:430px) {
    .navbar-toggler {
        margin-left: 43%;
    }

    .head a {
        font-size: 15px !important;
    }

    .bckimg {
        height: auto;
    }

    .smallborder1 {
        margin-left: calc(42% - 0px);
    }
}

@media(min-width:431px) and (max-width:575px) {
    .navbar-toggler {
        margin-left: 44%;
    }

    .head a {
        font-size: 16px !important;
    }

    .bckimg {
        height: auto;
    }

    .smallborder1 {
        margin-left: calc(44% - 0px);
    }
}

@media(min-width:576px) and (max-width:767px) {
    .navbar-toggler {
        margin-left: 46%;
    }

    .head a {
        font-size: 17px !important;
    }

    h4 {
        font-size: 11px;
    }

    .smallborder1 {
        margin-left: calc(46% - 0px);
    }
}

@media(min-width:768px) and (max-width:991px) {
    .navbar-light .navbar-nav .nav-link {
        padding: 5px 20px !important;
        font-size: 14px;
        font-weight: 600;
    }

    .navbar-light .navbar-nav .active>.nav-link {
        font-size: 14px;
        font-weight: 600;
    }

    .mt-4 {
        margin-top: 25px !important;
    }

    .mt-5 {
        margin-top: 5px !important;
    }

    .p-4 {
        padding: 15px !important;
    }

    .pt-5 {
        padding-top: 30px !important;
    }

    .px-5 {
        padding-right: 15px !important;
        padding-left: 15px !important;
    }

    .px-4 {
        padding-right: 15px !important;
        padding-left: 15px !important;
    }

    .mt-3 {
        margin-top: 10px !important;
    }

    .t1 {
        text-align: center !important;
    }

    .pb-5 {
        padding-bottom: 10px !important;
    }

    .head h1 {
        font-size: 22px;
        margin-top: 3px !important;
    }

    .foot p {
        font-size: 11px;
    }

    .drop a {
        font-size: 12px;
    }

    .navbar-expand-md .navbar-nav {
        margin-top: 15px;
    }

    .parallax {
        height: 0;
    }

    h2 {
        font-size: 27px;
    }

    h3 {
        font-size: 25px;
    }

    .w1 {
        width: 100%;
    }

    .head a {
        font-size: 15px !important;
    }

    .w2 {
        width: 100%;
    }

    h4 {
        font-size: 16px;
    }

    .smallborder1 {
        margin-left: calc(47% - 0px);
    }
}

@media(min-width:992px) and (max-width:1300px) {
    .navbar-light .navbar-nav .nav-link {
        padding: 0px 40px !important;
        font-size: 14px;
    }

    .navbar-light .navbar-nav .active>.nav-link {
        font-size: 14px;
    }

    .head h1 {
        font-size: 30px;
    }

    .mt-5 {
        margin-top: 45px !important;
    }

    .p-5 {
        padding: 15px !important;
    }

    .w1 {
        width: 100%;
    }

    h4 {
        font-size: 22px;
    }
}

@media(min-width:1370px) and (max-width:2500px) {
    .parallax {
        height: 0;
    }
}

@media(min-width:1370px) and (max-width:2500px) {
    .parallax {
        height: 0;
    }
}

@media(min-width:2501px) and (max-width:4500px) {
    .parallax {
        height: 0;
    }
}

@media(min-width:4501px) and (max-width:5500px) {
    .parallax {
        height: 0;
    }
}
</style>


<body>

    <!-- <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12" style="background-color:#FFFFC2;">
                <div align="center">
                    <a href="<?php echo base_url('Home') ?>"><button class="button-76" role="button">Home</button></a>
                    &nbsp
                    <a href="<?php echo base_url('SalesAdmin') ?>"><button class="button-76" role="button">Sales
                            Admin</button></a> &nbsp
                    <button class="button-76" role="button">Button 76</button> &nbsp
                    <button class="button-76" role="button">Button 76</button> &nbsp
                </div>
            </div>
        </div>
    </div> -->

    <div class="container-fluid">
        <nav class="navbar navbar-expand-md navbar-light">
            <div class="row text-center">
                <div class="col-sm-12 col-md-12 col-lg-12 text-center mt-3 head">
                    <a href="index.php" title="Thiru Adhiyavan Crackers"><img src="images/logo.jpg" height="80px"
                            width="250px"></a>
                </div>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#myNavbar">
                <i class="fa fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="navbar-nav ml-auto mt-2">
                    <li class="active fnt"><a href="index.php" class="nav-link"> Home </a></li>
                    <li class=" fnt"><a href="<?php echo base_url('SalesAdmin') ?>" class="nav-link">Sales Admin</a>
                    </li>
                    <li class=" fnt"><a href="<?php echo base_url('order') ?>" class="nav-link"> Quick Shop </a>
                    </li>
                    <li class=" fnt"><a href="<?php echo base_url('payment') ?>" class="nav-link">Make Payment</a>
                    </li>
                    <!-- <li class=" fnt"><a href="<?php echo base_url('SalesAdmin') ?>" class="nav-link"> Our Pricelist </a>
                    </li>-->
                    <li class=" fnt"><a href="<?php echo base_url('contactus') ?>" class="nav-link"> Contact Us </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</body>