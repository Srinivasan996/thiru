<!DOCTYPE html>
<html lang="en">
<?php
include 'Header.php';
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Datatable CSS -->
    <link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

    <!-- Datatable JS -->
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>
<!-- HTML !-->

<style>
.button-36 {
    background-image: linear-gradient(92.88deg, #455EB5 9.16%, #5643CC 43.89%, #673FD7 64.72%);
    border-radius: 8px;
    border-style: none;
    box-sizing: border-box;
    color: #FFFFFF;
    cursor: pointer;
    flex-shrink: 0;
    font-family: "Inter UI", "SF Pro Display", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
    font-size: 16px;
    font-weight: 500;
    height: 4rem;
    padding: 0 1.6rem;
    text-align: center;
    text-shadow: rgba(0, 0, 0, 0.25) 0 3px 8px;
    transition: all .5s;
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
}

.button-36:hover {
    box-shadow: rgba(80, 63, 205, 0.5) 0 1px 30px;
    transition-duration: .1s;
}

@media (min-width: 768px) {
    .button-36 {
        padding: 0 2.6rem;
    }
}

.input {
    border-radius: 5px;
    border-color: red;
}
</style>
<script type="text/javascript">
$(function() {
    $('#new_product_btn').click(function() {
        $("#new_product_model").modal('show');
    });
});
$(function() {
    $('#update_product_btn').click(function() {
        $("#update_product_model").modal('show');
    });
});
$(function() {
    $('#delete_product_btn').click(function() {
        $("#delete_product_model").modal('show');
    });
});
$(function() {
    $('#update_discount_product_btn').click(function() {
        $("#discount_product_model").modal('show');
    });
});
$(function() {
    $('#order_open_close').click(function() {
        $("#order_open_close_model").modal('show');
    });
});


/* function SalesAdminLogin() {
    //alert("call");
    var username_login = $("#username_login").val();
    var password_login = $("#password_login").val();
    //alert(password_login);
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/SalesAdminLogin",
        dataType: "json",
        beforeSend: function() {
            // $("body").mLoading();
        },
        success: function(response) {
            var item = response['value'];
            var username_db = item.username;
            var password_db = item.password;
            if (username_login == username_db && password_login == password_db) {
                Swal.fire({
                    //position: 'top-end',
                    icon: 'success',
                    title: 'Signed in successfully',
                    showConfirmButton: false,
                    timer: 1000
                })
                $("#login_model").modal('hide');
                $("#salesadmin_page").attr('hidden', 'false');
                $("#salesadmin_page").removeAttr('hidden');
            } else {
                Swal.fire({
                    //position: 'top-end',
                    icon: 'error',
                    title: 'Username and Password Wrong',
                    //showConfirmButton: false
                    //timer: 1000
                })
            }
        }
    });

} */

function getProductDetails() {
    // alert("HI");
    $('#update_product').attr('hidden', false);
    var getproduct_code = $("#getproduct_search").val();
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/getProductDetails",
        data: {
            "getproduct_code": getproduct_code
        },
        dataType: "json",
        beforeSend: function() {
            // $("body").mLoading();
        },
        success: function(response) {
            var item = response['value'];
            if (item.stock_detail == 'in') {
                $("#stock_update")
                    .css({
                        "color": "Green"
                    });
            }
            $("#product_code_update").val(item.product_id);
            $("#product_name_update").val(item.product_name);
            $("#content_item_update").val(item.content_item);
            $("#actual_price_update").val(item.actual_price);
            $("#discount_price_update").val(item.discout_price);
            $("#final_price_update").val(item.final_price);
            $("#stock_update").val(item.stock_detail);
        }
    });
    //
}

function updateProduct() {
    var product_code = $("#product_code_update").val();
    var product_name = $("#product_name_update").val();
    var content_item = $("#content_item_update").val();
    var actual_price = $("#actual_price_update").val();
    var discount_range = $("#discount_price_update").val();
    var final_price = $("#final_price_update").val();
    var stock = $("#stock_update").val();
    Swal.fire({
        icon: 'question',
        title: 'Are you sure Update the product details ?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Yes Update it',
        denyButtonText: `No Update it`,
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "crackers/Crackerscontrollers/updateProduct",
                data: {
                    "product_code": product_code,
                    "product_name": product_name,
                    "content_item": content_item,
                    "actual_price": actual_price,
                    "discount_range": discount_range,
                    "final_price": final_price,
                    "stock": stock
                },
                dataType: "json",
                beforeSend: function() {
                    // $("body").mLoading();
                },
                success: function(response)

                {
                    if (response) {
                        Swal.fire('Updated!', '', 'success')
                        $("#update_product_model").modal('hide');
                    }

                }
            });

        } else if (result.isDenied) {
            Swal.fire('Changes are not updated', '', 'info')
        }
    })

    //alert($('input[name=radio_stock]:checked', '#new_product_form').val());


}

function addNewProduct() {
    var product_code = $("#product_code").val();
    var product_name = $("#product_name").val();
    var content_item = $("#content_item").val();
    var actual_price = $("#actual_price").val();
    var discount_range = $("#discount_price").val();
    var final_price = $("#final_price").val();
    var stock = $('input[name=radio_stock]:checked', '#new_product_form').val();
    //alert($('input[name=radio_stock]:checked', '#new_product_form').val());
    Swal.fire({
        icon: 'question',
        title: 'Are you sure add the new product ?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Yes Add it',
        denyButtonText: `No Add it`,
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "crackers/Crackerscontrollers/addNewProduct",
                data: {
                    "product_code": product_code,
                    "product_name": product_name,
                    "content_item": content_item,
                    "actual_price": actual_price,
                    "discount_range": discount_range,
                    "final_price": final_price,
                    "stock": stock
                },
                dataType: "json",
                beforeSend: function() {
                    // $("body").mLoading();
                },
                success: function(response) {
                    if (response) {
                        Swal.fire('Added!', '', 'success')
                        $("#new_product_model").modal('hide');
                    }
                }
            });

        } else if (result.isDenied) {
            Swal.fire('New Product has been added in the list', '', 'info')
        }
    })


}

function updateDiscount() {
    var discount_price = $("#update_discount_price_input").val();
    /* $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/updateDiscount",
        data: {
            "discount_price": discount_price
        },
        dataType: "json",
        beforeSend: function() {
            // $("body").mLoading();
        },
        success: function(response) {

        }
    }); */
    Swal.fire({
        icon: 'question',
        title: 'Are you sure update the Discount Range?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Yes Update it',
        denyButtonText: `NO Update it`,
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "crackers/Crackerscontrollers/updateDiscount",
                data: {
                    "discount_price": discount_price
                },
                dataType: "json",
                beforeSend: function() {
                    // $("body").mLoading();
                },
                success: function(response) {
                    if (response) {
                        Swal.fire('Updated!', '', 'success')
                        $("#discount_product_model").modal('hide');
                    }

                }
            });

        } else if (result.isDenied) {
            Swal.fire('Changes are not updated', '', 'info')
        }
    })

    /*  Swal.fire({
         title: 'Are you sure?',
         text: "You won't be able to revert this!",
         icon: 'warning',
         showCancelButton: true,
         confirmButtonColor: '#3085d6',
         cancelButtonColor: '#d33',
         confirmButtonText: 'Yes, Update it!'
     }).then((result) => {
         if (result.isConfirmed) {
             $.ajax({
                 type: "POST",
                 url: "crackers/Crackerscontrollers/updateDiscount",
                 data: {
                     "discount_price": discount_price
                 },
                 dataType: "json",
                 beforeSend: function() {
                     // $("body").mLoading();
                 },
                 success: function(response) {
                     if (response) {
                         Swal.fire(
                             'Updated!',
                             ' Discount Price has been Updated.',
                             'success'
                         )
                     }

                 }
             });

         }
     }) */

}

function deleteProduct() {
    var delete_product_code = $("#delete_product_input").val();


    Swal.fire({
        icon: 'question',
        title: 'Are you sure delete the Product?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Yes Delete it',
        denyButtonText: `NO Delete it`,
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "crackers/Crackerscontrollers/deleteProduct",
                data: {
                    "delete_product_code": delete_product_code
                },
                dataType: "json",
                beforeSend: function() {
                    // $("body").mLoading();
                },
                success: function(response) {

                    if (response) {
                        Swal.fire('Deleted!', '', 'success')
                        $("#delete_product_model").modal('hide');
                    }
                }
            });

        } else if (result.isDenied) {
            Swal.fire('Product is not deleted ', '', 'info')
        }
    })


}
//UpdateOrderOpenClose
function CheckProduct() {
    //alert("call");
    var product_code_form = $("#product_code").val();
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/CheckProduct",
        dataType: "json",
        beforeSend: function() {
            // $("body").mLoading();
        },
        success: function(response) {
            for (var i = 0; i < response['value'].length; i++) {
                var item = response['value'][i];
                var product_code_db = item.product_id;
                if (product_code_form == product_code_db) {
                    Swal.fire('Already Exists Product Code!', '', 'warning')
                    //$("#delete_product_model").modal('hide');
                }
            }
        }
    });
}

function CheckProductUpdate() {
    var getproduct_search = $("#getproduct_search").val();
    var array = new Array();
    //var getproduct_search_array = new Array();
    //getproduct_search_array.push(getproduct_search);
    //alert(getproduct_search);
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/CheckProduct",
        dataType: "json",
        beforeSend: function() {
            // $("body").mLoading();
        },
        success: function(response) {
            for (var i = 0; i < response['value'].length; i++) {
                var item = response['value'][i];
                var product_code_db = item.product_id;
                array.push(item.product_id);


            }
            let result = array.includes(getproduct_search);
            if (result == false) {
                Swal.fire('Product Code Not Exits!', '', 'warning')
            }
        }
    });

}

function UpdateOrderOpenClose() {
    //alert("call");
    var open_close = $("#order_open_close_value").val();
    Swal.fire({
        icon: 'question',
        title: 'Are you sure update the Order is ' + open_close + '?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Yes Update it',
        denyButtonText: `NO Update it`,
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "crackers/Crackerscontrollers/UpdateOrderOpenClose",
                data: {
                    "open_close": open_close
                },
                dataType: "json",
                beforeSend: function() {
                    // $("body").mLoading();
                },
                success: function(response) {
                    if (response) {
                        Swal.fire('Updated!', '', 'success')
                        $("#order_open_close_model").modal('hide');
                    }

                }
            });

        } else if (result.isDenied) {
            Swal.fire('Changes are not updated', '', 'info')
        }
    })
}
$(document).ready(function() {
    //fetch list
    var list = '';
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/getOrderList",
        dataType: "json",
        async: false,
        beforeSend: function() {

        },
        success: function(response) {
            if (response['value'] != null) {
                for (var i = 0; i < response['value'].length; i++) {
                    var item = response['value'][i];

                    list = list + '<tr>';
                    list = list +
                        '<td style="text-align: left;">' + item.orderid + '</td>';
                    list = list +
                        '<td style="text-align: left;">' + item.customer + '</td>';
                    list = list +
                        '<td style="text-align: left;">' + item.phone + '</td>';
                    list = list +
                        '<td style="text-align: left;">' + item.email + '</td>';
                    list = list +
                        '<td class="" style="text-align:center;"> <a href = "OrderViewdetails?order_id=' +
                        item.orderid +
                        '"><button type="button" class="btn btn-danger" style = "margin-bottom:15px;font-weight:bold;" >View Order</button></a></td >';
                    list = list + '</tr>';
                }
                list = list +
                    '<tr id="notFound_not_payment"><td colspan=5 style="text-align:center; font-weight:bold; background-color:red; color:white;">No Matching Data</td></tr>';
                document.getElementById('order_list_not_payment_table_body').innerHTML =
                    list;
                $("#order_list_not_payment_table_body tr:even")
                    .css({
                        "background-color": "#58D68D",
                        "font-size": "13px",
                        "font-weight": "bold",
                        "color": "white"
                    });
                $("#order_list_not_payment_table_body tr:odd")
                    .css({
                        "background-color": "#F4F6F7",
                        "font-size": "13px",
                        "font-weight": "bold"
                    });
            } else {
                list = list +
                    '<tr style="background-color:white;"><th colspan="5"><center>No data</center></th></tr>';
                document.getElementById(
                        'order_list_not_payment_table_body')
                    .innerHTML = list;
            }


        },


    });
    var received_payment_list = '';
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/getOrderListPaymentReceived",
        dataType: "json",
        async: false,
        beforeSend: function() {

        },
        success: function(response) {
            if (response['value'] != null) {
                for (var i = 0; i < response['value'].length; i++) {
                    var item = response['value'][i];

                    received_payment_list = received_payment_list + '<tr>';
                    received_payment_list = received_payment_list +
                        '<td style="text-align: left;">' + item.orderid + '</td>';
                    received_payment_list = received_payment_list +
                        '<td style="text-align: left;">' + item.customer + '</td>';
                    received_payment_list = received_payment_list +
                        '<td style="text-align: left;">' + item.phone + '</td>';
                    received_payment_list = received_payment_list +
                        '<td style="text-align: left;">' + item.email + '</td>';
                    received_payment_list = received_payment_list +
                        '<td class="" style="text-align:center;"> <a href = "OrderViewdetails?order_id=' +
                        item.orderid +
                        '"><button type="button" class="btn btn-danger" style = "margin-bottom:15px; font-weight:bold;" >View Order</button></a></td >';
                    received_payment_list = received_payment_list + '</tr>';
                }
                received_payment_list = received_payment_list +
                    '<tr id="notFound_payment_received"><td colspan=5 style="text-align:center; font-weight:bold; background-color:red;color:white;">No Matching Data</td></tr>';
                document.getElementById('order_list_payment_received_table_body').innerHTML =
                    received_payment_list;
                $("#order_list_payment_received_table_body tr:even")
                    .css({
                        "background-color": "#E92561",
                        "font-size": "13px",
                        "font-weight": "bold",
                        "color": "white"
                    });
                $("#order_list_payment_received_table_body tr:odd")
                    .css({
                        "background-color": "#A9F5F2",
                        "font-size": "13px",
                        "font-weight": "bold"
                    });
            } else {
                received_payment_list = received_payment_list +
                    '<tr style="background-color:white;"><th colspan="5"><center>No data</center></th></tr>';
                document.getElementById(
                        'order_list_payment_received_table_body')
                    .innerHTML = received_payment_list;
            }

        },


    });
});
/* $(document).ready(function() {
    $('#order_list_table').DataTable({
        "pageLength": 5,
        "ajax": {
            url: "<?=site_url('crackers/Crackerscontrollers/getOrderList')?>",
            type: "GET"
        },
        "processing": true,
        "serverSide": true
    });

}); */


/* $(document).ready(function() {
    $("#open_order_not_payment").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#order_list_not_payment_table_body tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)

        });
    });
}); */

$(document).ready(function() {
    $("#notFound_not_payment").hide();
    $("#open_order_not_payment").on("keyup", function() {
        var value = $(this).val().toLowerCase()
        // select all items
        var allItems = $("#order_list_not_payment_table_body tr")
        // get list of matched items, (do not toggle them)
        var matchedItems = $("#order_list_not_payment_table_body tr").filter(function() {
            return $(this).text().toLowerCase().indexOf(value) > -1
        });
        // hide all items first
        allItems.toggle(false)

        // then show matched items
        matchedItems.toggle(true)
        // alert(matchedItems.length);
        // if no item matched then show notFound row, otherwise hide it
        if (matchedItems.length == 0) {
            // alert("Zero");
            $("#notFound_not_payment").show();
        } else {
            $("#notFound_not_payment").hide();
        }
    });
});
$(document).ready(function() {
    $("#notFound_payment_received").hide();
    $("#open_order_payment_received").on("keyup", function() {
        var value = $(this).val().toLowerCase()
        // select all items
        var allItems = $("#order_list_payment_received_table_body tr")
        // get list of matched items, (do not toggle them)
        var matchedItems = $("#order_list_payment_received_table_body tr").filter(function() {
            return $(this).text().toLowerCase().indexOf(value) > -1
        });
        // hide all items first
        allItems.toggle(false)

        // then show matched items
        matchedItems.toggle(true)
        // alert(matchedItems.length);
        // if no item matched then show notFound row, otherwise hide it
        if (matchedItems.length == 0) {
            // alert("Zero");
            $("#notFound_payment_received").show();
        } else {
            $("#notFound_payment_received").hide();
        }
    });
});
$('input').attr('autocomplete', 'off');
</script>

<body style="background-color:#FFFFC2;">
    <a href="<?php echo base_url('logout') ?>"><button type="button" class="btn btn-danger"
            style="margin-bottom:15px;margin-left:15px;">
            Logout</button></a>

    <div id="salesadmin_page">
        <div class="row">&nbsp</div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div align="center">
                        <button class="button-36" id="new_product_btn" role="button">Add New Product </button>
                        <button class="button-36" id="update_product_btn" role="button">Update Product </button>
                    </div>
                </div>
            </div>
            <div class="row">&nbsp</div>
            <div class="row">
                <div class="col-lg-12">
                    <div align="center">
                        <button class="button-36" id="update_discount_product_btn" role="button">Update
                            Discount</button>
                        <button class="button-36" id="delete_product_btn" role="button"> Delete Product </button>

                    </div>
                </div>
            </div>
            <div class="row">&nbsp
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div align="center">
                        <button class="button-36" id="order_open_close" role="button">Order
                            Open/Close</button>

                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="new_product_model" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="border-radius:10px;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="height:40px; background-color:#800000;border-radius:0px;">
                        <h5 class="modal-title" id="exampleModalLongTitle"
                            style="text-align:center; color:white;font-weight:bold; font-size:17px;">Add New
                            Product</h5><br>
                    </div>
                    <div class="modal-body">
                        <form id="new_product_form">
                            <div style="background-color:#90EE90;float:center; border-radius:5px;">
                                <div style="margin-left:20px;">
                                    <label for="product_code">Product Code:</label><br>
                                    <input type="text" id="product_code" class="input" name="product_code"
                                        onchange="CheckProduct();"><br>
                                    <label for="product_name">Product Name:</label><br>
                                    <input type="text" id="product_name" name="product_name" class="input"><br>
                                    <label for="content_item">Content Item:</label><br>
                                    <input type="text" id="content_item" name="content_item" class="input"><br>
                                    <label for="actual_price">Actual Price:</label><br>
                                    <input type="text" id="actual_price" name="actual_price" class="input"><br>
                                    <label for="discount_price">Discount Range:</label><br>
                                    <input type="text" id="discount_price" name="discount_price" class="input"><br>
                                    <label for="final_price">Final Price:</label><br>
                                    <input type="text" id="final_price" name="final_price" class="input"><br>
                                    <label for="stock">Stock:</label>
                                    <input type="radio" id="in" name="radio_stock" value="in">
                                      <label for="in">IN</label>
                                      <input type="radio" id="out" name="radio_stock" value="out">
                                      <label for="out">OUT</label>
                                    <div class="row">&nbsp</div>
                                    <button type="button" class="btn btn-primary" onclick="addNewProduct()"
                                        style="margin-bottom:15px;">Add
                                        Product</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="update_product_model" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="border-radius:10px;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="height:40px; background-color:#F6358A; border-radius:10px;">
                        <h5 class="modal-title" id="exampleModalLongTitle"
                            style="text-align:center; color:white;font-weight:bold; font-size:17px;">Update
                            Product Details</h5>
                    </div>
                    <div class="modal-body">
                        <form>
                            <div style="text-align:center;background-color:#800000; border-radius:15px;">
                                <div class="row">&nbsp</div>
                                <input type="search" name="getproduct_search" id="getproduct_search"
                                    onchange="CheckProductUpdate();" placeholder="Enter Product Code"
                                    style="height:33px; margin-bottom:3px; border-radius:10px; border-color:blue;"><br>
                                <button type="button" class="btn btn-success"
                                    style="margin-bottom:15px; border-radius:10px;" onclick="getProductDetails()">Get
                                    Product
                                    Details</button>

                            </div>
                            <div class="row">&nbsp</div>
                            <div style="background-color:#90EE90;float:center; border-radius:15px;" hidden
                                id="update_product">
                                <div style="margin-left:20px;">
                                    <label for="product_code">Product Code:</label><br>
                                    <input type="text" id="product_code_update" class="input" name="product_code"><br>
                                    <label for="product_name">Product Name:</label><br>
                                    <input type="text" id="product_name_update" name="product_name" class="input"><br>
                                    <label for="content_item">Content Item:</label><br>
                                    <input type="text" id="content_item_update" name="content_item" class="input"><br>
                                    <label for="actual_price">Actual Price:</label><br>
                                    <input type="text" id="actual_price_update" name="actual_price" class="input"><br>
                                    <label for="discount_price">Discount Range:</label><br>
                                    <input type="text" id="discount_price_update" name="discount_price"
                                        class="input"><br>
                                    <label for="final_price">Final Price:</label><br>
                                    <input type="text" id="final_price_update" name="final_price" class="input"><br>
                                    <label for="stock">Stock:</label><br>
                                    <select class="input" style="color:red; font-weight:bold;" id="stock_update">
                                        <option selected>Select Stock</option>
                                        <option value="in" style="color:green; font-weight:bold;">STOCK IN</option>
                                        <option value="out" style="color:red; font-weight:bold;">STOCK OUT</option>
                                    </select>
                                    <div class="row">&nbsp</div>
                                    <button type="button" class="btn btn-primary" onclick="updateProduct()"
                                        style="margin-bottom:15px;">Update
                                        Product</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="delete_product_model" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="border-radius:10px;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="height:40px; background-color:#B43104; border-radius:10px;">
                        <h5 class="modal-title" id="exampleModalLongTitle"
                            style="text-align:center; color:white;font-weight:bold; font-size:17px;">Remove
                            Product from the list</h5>
                    </div>
                    <div class="modal-body">
                        <form>
                            <div style="text-align:center; background-color:#81F79F; border-radius:15px;">
                                <div class="row">&nbsp</div>
                                <input type="search" name="delete_product_input" id="delete_product_input"
                                    placeholder="Enter Product Code"
                                    style="height:33px; margin-bottom:3px; border-radius:10px; border-color:blue;"><br>
                                <button type="button" class="btn btn-danger"
                                    style="margin-bottom:15px; border-radius:10px;" onclick="deleteProduct()">Delete
                                    Product</button>

                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="order_open_close_model" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="border-radius:10px;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="height:40px;border-radius:10px;">
                        <h5 class="modal-title" id="exampleModalLongTitle"
                            style="text-align:center; color:red;font-weight:bold; font-size:17px;">Order Open/Close
                        </h5>
                    </div>
                    <div class="modal-body">

                        <div align="center">
                            <select class="input"
                                style="color:green; font-weight:bold; width: 200px; height:50px; font-size:20px;"
                                id="order_open_close_value" onchange="UpdateOrderOpenClose();">
                                <option selected>Selec Order Open/Close</option>
                                <option value="open" style="color:green; font-weight:bold;">Order has benn Open right
                                    now</option>
                                <option value="closed" style="color:red; font-weight:bold;">Order has been Closed right
                                    now</option>
                            </select>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="discount_product_model" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="border-radius:10px;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="height:40px; background-color:#5F04B4; border-radius:10px;">
                        <h5 class="modal-title" id="exampleModalLongTitle"
                            style="text-align:center; color:white;font-weight:bold; font-size:17px;">Update
                            Discount Percentage </h5>
                    </div>
                    <div class="modal-body">
                        <form>
                            <div style="text-align:center;background-color:#FE2E64; border-radius:15px;">
                                <div class="row">&nbsp</div>
                                <input type="search" name="update_discount_price_input" id="update_discount_price_input"
                                    placeholder="Enter Discount Percentage"
                                    style="height:33px; margin-bottom:3px; border-radius:10px; border-color:blue;"><br>
                                <button type="button" class="btn btn-primary"
                                    style="margin-bottom:15px; border-radius:10px;" onclick="updateDiscount()">Update
                                    Discount</button>

                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">&nbsp</div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12" style="background-color:#641b08; border-radius:10px;">
                    <p style="text-align: left; font-weight: bold; font-size:18px;color:white;">Open Orders -
                        Payment
                        Received
                    </p>
                    <input id="open_order_payment_received" type="text" placeholder="Search..">
                    <table class="table table-responsive" id="order_list_table">
                        <thead>
                            <tr style="background-color:#273746;color:white;">
                                <th>OrderID</th>
                                <th>Customer Name</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="order_list_payment_received_table_body">
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <div class="row">&nbsp</div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12" style="background-color:#641b08; border-radius:10px;">
                    <p style="text-align: left; font-weight: bold; font-size:18px;color:white;">Open Orders -
                        Payment
                        Not
                        Received </p>
                    <input id="open_order_not_payment" type="text" placeholder="Search..">
                    <table class="table table-responsive" id="order_list_table">
                        <thead>
                            <tr style="background-color:#273746; color:white;">
                                <th>OrderID</th>
                                <th>Customer Name</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="order_list_not_payment_table_body">
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
    <!--div class="modal fade" id="login_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-header" style="height:40px;">
                        <h5 class="modal-title" id="exampleModalLongTitle"
                            style="text-align:center; color:Green;font-weight:bold; font-size:17px;">Sales Admin Login
                        </h5>
                    </div>
                </div>
                <div class="modal-body">
                    <div style="text-align:center;background-color:#FE2E64; border-radius:15px;">
                        <div class="row">&nbsp</div>
                        <input type="text" id="username_login" placeholder="Enter Username" name="uname"
                            class="form-control" required style="width:50%; margin-left:120px; font-weight:bold;"><br>
                        <input type="password" id="password_login" placeholder="Enter Password" name="psw"
                            class="form-control" required style="width:50%;margin-left:120px;font-weight:bold;">
                        <div class="row">&nbsp</div>
                        <button type="submit" class="btn btn-success" onclick="SalesAdminLogin();">Login</button>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="container" style="background-color:#f1f1f1">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
        </div>-->
</body>

</html>