<!DOCTYPE html>
<html lang="en">
<?php
include 'Header.php';
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Datatable CSS -->
    <link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>

    <!-- Datatable JS -->
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"> </script>
    <script src="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.6/jspdf.plugin.autotable.min.js"></script>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"></script>
    <script type="text/javascript">
    (function() {
        emailjs.init("user_LsELqCmbqfjgOBQvu71C1");
    })();
    </script>

</head>

<style>
.col-12 {
    background-color: #800000;
    color: white;
    text-align: left;
    font-size: 14px;
    font-weight: bold;


}

.label_details {
    //background-color: #A9F5A9;
    font-size: 18px;
    font-weight: underline;

}

#simple_table table,
td,
th,
tr {
    border: 1px solid black;

}

th {
    text-align: center;
}

th #simple_table {
    font-size: 18px !important;
    background-color: #FE2E64 !important;
    color: white !important;
}
</style>
<script type="text/javascript">
$(document).ready(function() {
    var order_id = '<?php echo $order_id; ?>';
    //alert(order_id);
    var OrderItemlist = '';
    var OrderItemlist_pdf = '';

    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/getOrderList_View",
        data: {
            "order_id_view": order_id
        },
        dataType: "json",
        async: false,
        beforeSend: function() {

        },
        success: function(response) {
            //alert(response);
            var item = response['value'];
            $('#orderid').text(item.orderid);
            $('#customer_phone').text(item.phone);
            $('#customer_name').text(item.customer);
            $('#customer_email').text(item.email);
            $('#customer_address').text(item.address);
            $('#status').val(item.status);
            // alert(item.Total_amount);
            $('#overall_total_amount').text(item.Total_amount);

            //----------------PDF view---------------
            $('#orderid_pdf').text(item.orderid);
            $('#customer_phone_pdf').text(item.phone);
            $('#customer_name_pdf').text(item.customer);
            $('#customer_email_pdf').text(item.email);
            var address_pdf = $('#customer_address').text();
            $('#customer_address_pdf').text(address_pdf);
            //document.getElementById('order_list_table_body_customer_details').innerHTML = list;
        },


    });
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/getOrderItemList_View",
        data: {
            "order_id_view": order_id
        },
        dataType: "json",
        async: false,
        beforeSend: function() {

        },
        success: function(response) {
            //alert(response);
            for (var i = 0; i < response['value'].length; i++) {
                var item = response['value'][i];
                var s_no = i + 1;
                OrderItemlist = OrderItemlist + '<tr>';
                OrderItemlist = OrderItemlist +
                    '<td style="text-align: left;">' + s_no + '</td>';
                OrderItemlist = OrderItemlist +
                    '<td style="text-align: left;">' + item.product_name + '</td>';
                OrderItemlist = OrderItemlist +
                    '<td style="text-align: left;">' + item.content_item + '</td>';
                OrderItemlist = OrderItemlist +
                    '<td style="text-align: left;">' + item.quantity + '</td>';
                OrderItemlist = OrderItemlist + '</tr>';
            }
            document.getElementById('order_list_table_body_item_details').innerHTML =
                OrderItemlist;

        },


    });

    // ----------------------PDF View ------------------------
    var overall_total_amount = $('#overall_total_amount').text();
    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/getOrderItemList_View",
        data: {
            "order_id_view": order_id
        },
        dataType: "json",
        async: false,
        beforeSend: function() {

        },
        success: function(response) {
            //alert(response);
            for (var i = 0; i < response['value'].length; i++) {
                var s_no = i + 1;
                var item = response['value'][i];
                OrderItemlist_pdf = OrderItemlist_pdf + '<tr>';
                OrderItemlist_pdf = OrderItemlist_pdf +
                    '<td style="text-align: center;">' + s_no + '</td>';
                OrderItemlist_pdf = OrderItemlist_pdf +
                    '<td style="text-align: center;">' + item.product_name + '</td>';
                OrderItemlist_pdf = OrderItemlist_pdf +
                    '<td style="text-align: center;">' + item.content_item + '</td>';
                OrderItemlist_pdf = OrderItemlist_pdf +
                    '<td style="text-align: center;">' + item.actual_price + '</td>';
                OrderItemlist_pdf = OrderItemlist_pdf +
                    '<td style="text-align: center;">' + item.discountminus_price + '</td>';
                OrderItemlist_pdf = OrderItemlist_pdf +
                    '<td style="text-align: center;">' + item.final_price + '</td>';
                OrderItemlist_pdf = OrderItemlist_pdf +
                    '<td style="text-align: center;">' + item.quantity + '</td>';
                OrderItemlist_pdf = OrderItemlist_pdf +
                    '<td style="text-align: center;">' + item.item_total + '</td>';
                OrderItemlist_pdf = OrderItemlist_pdf + '</tr>';
            }
            OrderItemlist_pdf = OrderItemlist_pdf + '<tr>';
            OrderItemlist_pdf = OrderItemlist_pdf +
                '<td colspan=7 style="text-align:right;"> Total Amount </td>';
            OrderItemlist_pdf = OrderItemlist_pdf + '<td style="text-align: center;">' +
                overall_total_amount + '</td>';
            OrderItemlist_pdf = OrderItemlist_pdf + '</tr>';

            document.getElementById('order_list_table_body_item_details_pdf').innerHTML =
                OrderItemlist_pdf;
            $("#simple_table tr:even").css({
                "background-color": "#F5A9F2",
                "font-size": "13px",
                "font-weight": "bold"
            });
            $("#simple_table tr:odd").css({
                "background-color": "#A9F5F2",
                "font-size": "13px",
                "font-weight": "bold"
            });

        },


    });


});

function UpdateStatus() {
    var status = $('#status').val();
    var orderid = $('#orderid').text();
    // alert(orderid);

    $.ajax({
        type: "POST",
        url: "crackers/Crackerscontrollers/UpdateStatus",
        data: {
            "status": status,
            "orderid": orderid
        },
        dataType: "json",
        async: false,
        beforeSend: function() {

        },
        success: function(response) {
            //alert(response);
            Swal.fire('Status Successfully Updated ', '', 'success')
            //document.getElementById('order_list_table_body_customer_details').innerHTML = list;
        },


    });

}

function generatepdf() {

}

function generate() {
    var doc = new jsPDF('p', 'pt', 'a4', true);
    var customer_details = $('#customer_details').html();
    var htmlstring = '';
    var tempVarToCheckPageHeight = 0;
    var pageHeight = 0;
    pageHeight = doc.internal.pageSize.height;
    specialElementHandlers = {
        // element with id of "bypass" - jQuery style selector
        '#bypassme': function(element, renderer) {
            // true = "handled elsewhere, bypass text extraction"
            return true
        }

    };
    var y = 20;
    //doc.text(200, y = y + 30, "Order Details");
    doc.setLineWidth(2);
    specialElementHandler = {
        // element with id of "bypass" - jQuery style selector
        '#elementH': function(element, renderer) {
            return true;
        }
    };
    doc.fromHTML(customer_details, 30, 30, {
        'width': 700
        // 'elementHandlers': specialElementHandler
    });


    margins = {
        top: 150,
        bottom: 60,
        left: 40,
        right: 40,
        width: 700
    };

    doc.setLineWidth(2);
    doc.autoTable({
        html: '#simple_table',
        startY: 150,
        theme: 'grid',
        columnStyles: {
            0: {
                cellWidth: 30,
            },
            1: {
                cellWidth: 180,
            },
            2: {
                cellWidth: 50,
            },
            3: {
                cellWidth: 50,
            },
            4: {
                cellWidth: 80,
            },
            5: {
                cellWidth: 50,
            },
            6: {
                cellWidth: 30,
            },
            7: {
                cellWidth: 70,
            }
        },
        styles: {
            minCellHeight: 10
        },
        theme: "striped",
        didDrawPage: function(data) {
            // Header
            // doc.setFontSize(20);
            // doc.setTextColor(20, 255, 0);
            // doc.text("Thiru Adhiyavan Crackers", data.settings.margin.left, 22);
        }
    })
    var orderid = $('#orderid').text();
    doc.save('Booking_details' + orderid + '.pdf');
}

//document.querySelector('#jsPDF').addEventListener('click', downloadPDFWithjsPDF);


function sendEmail() {
    var table_items = document.getElementById("email").innerHTML;
    var emailbody = '<html>';
    emailbody = emailbody + '<body><h3 style="background-color:red; color:white;">Summary Your Order Details</h3>';
    emailbody = emailbody + table_items;
    emailbody = emailbody + '</body>';
    emailbody = emailbody + '</html>';
    // alert(emailbody);
    //console.log(emailbody);

    Email.send({
        Host: "smtp.gmail.com",
        Username: "thiruadhiyavancrackers2022@gmail.com",
        Password: "xiusrqqacujaeswc",
        To: 'vssrini402@gmail.com',
        From: "thiruadhiyavancrackers2022@gmail.com",
        Subject: "Crackers Booking Details - Thiru Adhiyavan Crackers",
        Body: emailbody
    }).then(
        message => alert("mail sent successfully new")
    );
    /*   Email.send({
         // SecureToken: "dd8fbfd9-ab8a-4276-9df4-fe4c98377019",

          To: 'srinivasanmaha959@gmail.com',
          From: "sriniblog1@gmail.com",
          Subject: "Thiru Crackers",
          Body: "And this is the body"
      }).then(
          message => alert("mail sent successfully smtpjs")
      ); */
}
</script>


<body style="background-color:#FFFFC2;">

    <div class="container-fluid">
        <a href="<?php echo base_url('sales') ?>"><button type="button" class="btn btn-success"
                style="margin-bottom:15px;">
                Back to List</button></a><br>
        <button id="jsPDF" class="btn btn-primary" onclick="generate()">Generate PDF</button>
        <div class="row">&nbsp</div>
        <div>
            <select id="status" class="input"
                style="color:green; font-weight:bold; width:150px; height:40px; font-size:17px;"
                id="order_open_close_value" onchange="UpdateStatus();">
                <option selected>Selec Order Status</option>
                <option value="open">Open/Awaiting Payment</option>
                <option value="Payment Received">Payment Received</option>
                <option value="closed">Closed</option>
            </select>
        </div>
        <div class="row">&nbsp</div>
        <div class="row">
            <div class="col-12">
                <div>
                    <label class="label_details">OrderID : </label>
                    <pre id="orderid"> </pre><br>
                    <label class="label_details"> Mobile Number : </label>
                    <pre id="customer_phone"></pre><br>
                    <label class="label_details"> Customer Name : </label>
                    <pre id="customer_name">
                    </pre><br>
                    <label class="label_details"> Total Amount: </label>
                    <pre id="overall_total_amount">
                    </pre><br>

                </div>
            </div>

            <!-- Force next columns to break to new line -->
            <div class="w-100"></div>
            <div class="col-12">
                <div>
                    <label class="label_details">Email : </label>
                    <pre id="customer_email"></pre><br>
                    <label class="label_details">Address : </label><br>
                    <pre id="customer_address"></pre>
                </div>
            </div>


        </div>
    </div>

    <div class="row">&nbsp</div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <table class="table table-striped" id="order_list_item_details ">
                    <thead>
                        <tr style="background-color:#FE2E64; color:white;">
                            <th>S.No</th>
                            <th>Product Name</th>
                            <th>Content Item</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody id="order_list_table_body_item_details" style="background-color:#BEF781;">
                    </tbody>
                </table>

            </div>
        </div>
    </div>

    <!--<button id="sendemail" onclick="sendEmail()">Send Email</button>-->
    <!---------------------------PDF table ------------------------------>
    <div id="email" hidden>
        <div id="customer_details">
            <div class="row">
                <div class="col-6">
                    <label class="label_details">OrderID : </label><span id="orderid_pdf"> </span><br>
                    <label class="label_details">Mobile Number : </label><span id="customer_phone_pdf"></span><br>
                    <label class="label_details">Customer Name : </label><span id="customer_name_pdf"></span><br>
                    <label class="label_details">Email : </label> <span id="customer_email_pdf"></span><br>
                    <label class="label_details">Address : </label>
                    <span id="customer_address_pdf" style="word-break: break-all;"></span>

                </div>
            </div>
        </div>
        <br>
        <br>
        <div id="styledTable">
            <table class="table table-striped" id="simple_table">
                <thead>
                    <tr style="background-color:#FE2E64; color:red;">
                        <th>S No</th>
                        <th>Product Name</th>
                        <th>Content Item</th>
                        <th>Actual Price</th>
                        <th>Discount Price</th>
                        <th>Final Price</th>
                        <th>Qty</th>
                        <th>TotalPrice</th>
                    </tr>
                </thead>
                <tbody id="order_list_table_body_item_details_pdf">
                    <!--style="background-color:#BEF781;"-->
                </tbody>
            </table>
        </div>
    </div>

</body>