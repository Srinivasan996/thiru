<!DOCTYPE html>
<html lang="en">
<?php
include 'Header.php';
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="js/jquery.fireworks.js"></script>

</head>
<style>
.clr1 {
    color: #377b00 !important;
    font-weight: bold;
}

.clr {
    color: #f20505 !important;
}

.single-line {
    color: #ff1a8c !important;
}

.fnt {
    font-family: "Poppins", sans-serif;
}

.fntweight {
    font-weight: 800 !important;
}

.lh {}

.text-justify {
    text-align: 'justify!important';
}

.mt-3 {
    margin-top: 1rem !important;
}

p {
    font-size: 15px;
    line-height: 1.8em;
}

.w1 {
    width: 100%;
}

.mt-4 {
    margin-top: 1.5rem !important;
}

.mt-2 {
    margin-top: .5rem !important;
}

.mt-3 {
    margin-top: 10px !important;
}

ul>li {
    display: block;
    padding: 10px 0px;
}


.px-5 {
    padding-left: 3rem !important;
    padding-right: 3rem !important;
}

.my-5 {
    margin-bottom: 3rem !important;
    margin-top: 3rem !important;
}

.brdr {
    border: 2px solid #3a006a !important;
    border-radius: 50px;
}

.py-2 {
    padding-bottom: .5rem !important;
}

.fnt {
    font-family: "Poppins", sans-serif;
}

a {
    text-decoration: none !important;
    color: #353535 !important;
}

.px-4 {
    padding-right: 15px !important;
    padding-left: 15px !important;
}

.w2 {
    width: 120%;
}

.check-btn {
    background-color: red;
    font-size: 20px;
    color: white !important;
    font-weight: bold !important;
    ;



}

.foot {
    background-color: #F2F3F4 !important;
}

li {
    line-height: 2rem;
}

img {}
</style>



<body id="body" style="background-color:#FFFFC2;">
    <div class="container-fluid p-0">
        <!--Carousel-->
        <div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="images/banner4.jpg" class="img-fluid w-100 d-block" alt="THiru Adhiyavan Crackers"
                        title="THiru Adhiyavan Crackers">
                </div>
                <div class="carousel-item">
                    <img src="images/banner2.png" class="img-fluid w-100 d-block" alt="THiru Adhiyavan Crackers"
                        title="THiru Adhiyavan Crackers">
                </div>
                <div class="carousel-item">
                    <img src="images/banner3.jpg" class="img-fluid w-100 d-block" alt="THiru Adhiyavan Crackers"
                        title="THiru Adhiyavan Crackers">
                </div>

            </div>
            <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <!--Carousel End-->
    </div>
    <div class="container-fluid px-5 my-5">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 img-thumbnail">
                <div class="text-center">
                    <a href="index.php" title="Thiru Adhiyavan Crackers">
                        <h1 class="fnt fntweight text-center mb-3 clr fnt">Thiru Adhiyavan Crackers</h1>
                    </a>
                    <div class="smallborder1"></div>
                    <p class="text-center lh mt-3">
                        Kadamadai Village. <br>Palacode, Dharmapuri - 636808,Tamil Nadu<br>India. </p>
                    <p> WhatsApp: <a class="clr1 lh" target="_blank"
                            href="https://api.whatsapp.com/send?phone=919751089536" title="Whatsapp"> +91-9751089536</a>
                        <a class="clr1 lh" target="_blank" href="https://api.whatsapp.com/send?phone=918124823812"
                            title="Whatsapp"> +91-8124823812</a><br>
                        <a class="clr1 lh" target="_blank" href="https://api.whatsapp.com/send?phone=919942328042"
                            title="Whatsapp"> +91-9942328042</a>
                        <a class="clr1 lh" target="_blank" href="https://api.whatsapp.com/send?phone=919994994061"
                            title="Whatsapp"> +91-9994994061</a>
                    <p class="text-center lh mt-3"> Mobile Number: +91-9751089536 , +91-8838653313, +91-8072665469</p>

                    <p> Email Id : <a class="clr1 lh" href="mailto:thiruadhiyavancrackers2022@gmail.com"
                            title="thiruadhiyavancrackers2022@gmail.com">
                            thiruadhiyavancrackers2022@gmail.com</a></p>
                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-6 img-thumbnail">
                <h2 class="text-center clr fnt fntweight"> Check <span class="clr1">Price</span></h2>
                <div class="smallborder1"></div>
                <p class="text-center lh mt-3"> Quality products at economic price is the main motto for us. Check our
                    pricelist to get more details about our products and price. </p>
                <div class="my-4 text-center"><a class="px-4 py-2 brdr fnt clr3" href="<?php echo base_url('order') ?>"
                        title="Check Now">
                        Check Now . . </a>
                </div>
            </div>
        </div>
    </div>
</body>