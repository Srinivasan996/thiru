<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Crackersmodel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        // $crackers = $this->load->database('crackers', true);
        //$this->load->database('default');

        //$this->load->library('session');
    }

    public function getproductlist()
    {
        $crackers = $this->load->database('crackers', true);
        $sql = 'select product_id,product_name,content_item,actual_price,discout_price,final_price,stock_detail,image_name from product_list';
        $q = $crackers->query($sql);
        $result = $q->result();
        return $result;
    }
    public function getOrderList()
    {
        $crackers = $this->load->database('crackers', true);
        $status = 'open';
        $sql = "select orderid,phone,customer,email,address,Total_amount from ordersnew where status ='$status'";
        // $query=$crackers->offset($start)->limit($length)->get('ordersnew');
        $q = $crackers->query($sql);
        $result = $q->result();
        return $result;

    }
    public function getOrderListPaymentReceived()
    {
        $crackers = $this->load->database('crackers', true);
        $status = 'Payment Received';
        $sql = "select orderid,phone,customer,email,address,Total_amount from ordersnew where status ='$status'";
        // $query=$crackers->offset($start)->limit($length)->get('ordersnew');
        $q = $crackers->query($sql);
        $result = $q->result();
        return $result;

    }
    public function getLatestRecord()
    {
        $crackers = $this->load->database('crackers', true);
        /*  $last = $this->$crackers->order_by('id', "desc")
        ->limit(1)
        ->get('order')
        ->row(); */
        $sql = "SELECT * FROM `order` order BY id DESC LIMIT 1";
        $q = $crackers->query($sql);
        $result = $q->result();
        return $result;

        // $result = $last->result();
        // return $result;

    }
    public function getTotalOrderList()
    {
        $crackers = $this->load->database('crackers', true);
        //    $query = $crackers->select('COUNT(*) as total_records')->get('ordersnew');
        return $this->$crackers->count_all("ordersnew");

    }
    public function OrderItems($order_items, $name, $phone_number, $email, $address, $orderid, $overall_total_amount)
    {
        $crackers = $this->load->database('crackers', true);
        $status = 'open';
        $query = "INSERT INTO `ordersnew`(`orderid`,`customer`,`phone`, `address`, `email`,`status`,`Total_amount`) VALUES ('$orderid','$name','$phone_number','$address','$email','$status','$overall_total_amount')";
        $query_order = "INSERT INTO `order`(`orderid`) VALUES ('$orderid')";
        //print_r($query);
        $result = $crackers->query($query);
        $result = $crackers->query($query_order);
        foreach ($order_items as $row) {
            $product_name = $row['product_name'];
            $content_item = $row['content_item'];
            // $image_name=$row['image_name'];
            $actual_price = $row['actual_price'];
            $discountminus_price = $row['discount_price'];
            $final_price = $row['final_price'];
            $quantity = $row['quantity'];
            $item_total = $row['item_total'];

            $query1 = "INSERT INTO `orderitemsnew`(`orderid`,`product_name`, `content_item`, `image_name`, `actual_price`, `discountminus_price`, `final_price`, `quantity`, `item_total`)
       VALUES ('$orderid','$product_name','$content_item','','$actual_price','$discountminus_price','$final_price','$quantity','$item_total')";
            // print_r($query1);
            // exit;

            $crackers->query($query1);
        }

        return true;
    }
    public function Orders($orderid, $name, $phone_number, $email, $address)
    {
        $crackers = $this->load->database('crackers', true);
        $query = "INSERT INTO `ordersnew`(`orderid`,`customer`,`phone`, `address`, `email`) VALUES ('$orderid','$name','$phone_number','$address','$email')";
        //print_r($query);
        $crackers->query($query);
        return true;

    }
    public function addNewProduc($product_code, $product_name, $content_item, $actual_price, $discount_range, $final_price, $stock)
    {
        $crackers = $this->load->database('crackers', true);
        $query = "INSERT INTO `product_list`(`product_id`,`product_name`, `content_item`, `actual_price`,`discout_price`,`final_price`,`stock_detail`)
        VALUES ('$product_code','$product_name','$content_item','$actual_price','$discount_range','$final_price','$stock')";
        //print_r($query);
        $crackers->query($query);
        return true;

    }
    public function updateProduct($product_code, $product_name, $content_item, $actual_price, $discount_range, $final_price, $stock)
    {
        $crackers = $this->load->database('crackers', true);
        $query = "UPDATE `product_list` SET `product_id`='$product_code',`product_name`='$product_name',
        `content_item`='$content_item',`actual_price`='$actual_price',`discout_price`='$discount_range',`final_price`='$final_price',`stock_detail`='$stock' WHERE product_id='$product_code'";
        //print_r($query);
        $crackers->query($query);
        return true;

    }
    public function getProductDetails($getproduct_code)
    {
        $crackers = $this->load->database('crackers', true);
        $sql = "SELECT `product_id`, `product_name`, `content_item`, `actual_price`, `discout_price`, `final_price`, `stock_detail` FROM `product_list` WHERE product_id='$getproduct_code'";
        $q = $crackers->query($sql);
        $result = $q->result();
        //print_r($result);
        return $result;

    }
    public function updateDiscount($discount_price)
    {
        $crackers = $this->load->database('crackers', true);
        $query = "UPDATE `product_list` SET `discout_price`='$discount_price'";
        //print_r($query);
        $crackers->query($query);
        return true;

    }
    public function deleteProduct($delete_product_code)
    {
        $crackers = $this->load->database('crackers', true);
        $query = "DELETE FROM `product_list` WHERE product_id='$delete_product_code'";
        //print_r($query);
        $crackers->query($query);
        return true;

    }
    public function getOrderList_View($order_id_view)
    {
        $crackers = $this->load->database('crackers', true);
        $sql = "SELECT `orderid`, `Total_amount`, `status`, `phone`, `customer`, `email`, `address` FROM `ordersnew` WHERE orderid='$order_id_view'";
        $q = $crackers->query($sql);
        $result = $q->result();
        //print_r($result);
        return $result;

    }
    public function UpdateStatus($orderid, $status)
    {
        $crackers = $this->load->database('crackers', true);
        $query = "UPDATE `ordersnew` SET `status`='$status' where `orderid`='$orderid'";
        //print_r($query);
        $crackers->query($query);
        return true;

    }
    public function UpdateOrderOpenClose($open_close)
    {
        $crackers = $this->load->database('crackers', true);
        $query = "UPDATE `orderopenclosed` SET `orderopen_closed`='$open_close' where `id`='1'";
//print_r($query);
        $crackers->query($query);
        return true;

    }
    public function getOrderItemList_View($order_id_view)
    {
        $crackers = $this->load->database('crackers', true);
        $sql = "SELECT `orderid`, `product_name`, `content_item`, `actual_price`, `discountminus_price`, `final_price`, `quantity`,`item_total` FROM `orderitemsnew` WHERE orderid='$order_id_view' and `quantity`!=0";
        $q = $crackers->query($sql);
        $result = $q->result();
        //print_r($result);
        return $result;

    }
    public function SalesAdminLogin()
    {
        $crackers = $this->load->database('crackers', true);
        $sql = "SELECT * FROM `salesadmin`";
        $q = $crackers->query($sql);
        $result = $q->result();
        return $result;
    }
    public function OrderOpenClosed()
    {
        $crackers = $this->load->database('crackers', true);
        $sql = "SELECT * FROM `orderopenclosed`";
        $q = $crackers->query($sql);
        $result = $q->result();
        return $result;

    }
}