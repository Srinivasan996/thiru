<?php
class User_model extends CI_Model
{
    public function store($data)
    {
        $this->db->insert('user', $data);
        return true;
    }
    public function SalesAdminLogin()
    {
        $crackers = $this->load->database('crackers', true);
        $sql = "SELECT * FROM `salesadmin`";
        $q = $crackers->query($sql);
        $result = $q->result();
        return $result;
    }
}